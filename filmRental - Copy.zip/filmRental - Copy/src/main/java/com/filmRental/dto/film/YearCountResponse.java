package com.filmRental.dto.film;

/** Response for /api/films/countbyyear */
public class YearCountResponse {
    private Integer releaseYear;
    private Long count;

    public YearCountResponse(Integer releaseYear, Long count) {
        this.releaseYear = releaseYear;
        this.count = count;
    }

    public Integer getReleaseYear() { return releaseYear; }
    public Long getCount() { return count; }


	public void setReleaseYear(Integer releaseYear) {
		this.releaseYear = releaseYear;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public YearCountResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}