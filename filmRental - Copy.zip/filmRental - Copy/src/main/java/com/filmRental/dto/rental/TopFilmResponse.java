package com.filmRental.dto.rental;

public class TopFilmResponse {
    private Integer filmId;
    private String title;
    private Long rentals;

    public Integer getFilmId() {
        return filmId;
    }

    public void setFilmId(Integer filmId) {
        this.filmId = filmId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getRentals() {
        return rentals;
    }

    public void setRentals(Long rentals) {
        this.rentals = rentals;
    }
}