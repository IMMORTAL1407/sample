package com.filmRental.dto.customer;

import jakarta.validation.constraints.NotNull;


/** Request body for PUT /api/customers/{id}/address */

public class AssignAddressRequest {
    @NotNull(message = "addressId is required")
    private Integer addressId;

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public AssignAddressRequest(@NotNull(message = "addressId is required") Integer addressId) {
		super();
		this.addressId = addressId;
	}

	public AssignAddressRequest() {
		super();
		// TODO Auto-generated constructor stub
		
		
	}
    
    
}