package com.filmRental.dto.actor;


public class ActorFilmResponse {

    private Integer filmId;
    private String title;
    private Integer releaseYear;

    public ActorFilmResponse(Integer filmId, String title, Integer releaseYear) {
        this.filmId = filmId;
        this.title = title;
        this.releaseYear = releaseYear;
    }

	public Integer getFilmId() {
		return filmId;
	}

	public void setFilmId(Integer filmId) {
		this.filmId = filmId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(Integer releaseYear) {
		this.releaseYear = releaseYear;
	}
    

}
