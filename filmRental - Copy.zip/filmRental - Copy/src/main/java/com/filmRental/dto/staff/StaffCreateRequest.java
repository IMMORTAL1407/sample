package com.filmRental.dto.staff;


import jakarta.validation.constraints.*;

public class StaffCreateRequest {

    @NotNull(message = "storeId is required")
    private Integer storeId;

    @NotNull(message = "addressId is required")
    private Integer addressId;

    @NotBlank(message = "firstName is required")
    @Size(max = 45, message = "firstName must be <= 45 characters")
    private String firstName;

    @NotBlank(message = "lastName is required")
    @Size(max = 45, message = "lastName must be <= 45 characters")
    private String lastName;

    @Email(message = "email must be valid")
    @Size(max = 50, message = "email must be <= 50 characters")
    private String email; // optional

    @NotBlank(message = "username is required")
    @Size(max = 16, message = "username must be <= 16 characters")
    private String username;

    @Size(max = 40, message = "password must be <= 40 characters")
    private String password; // optional (nullable in schema)

    // Optional - defaults to true if null
    private Boolean active;

    public Integer getStoreId() { return storeId; }
    public void setStoreId(Integer storeId) { this.storeId = storeId; }
    public Integer getAddressId() { return addressId; }
    public void setAddressId(Integer addressId) { this.addressId = addressId; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }
    
    
}
