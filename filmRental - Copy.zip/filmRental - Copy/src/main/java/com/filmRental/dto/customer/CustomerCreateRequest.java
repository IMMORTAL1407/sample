package com.filmRental.dto.customer;

import jakarta.validation.constraints.*;

/**
 * Request body to create a new Customer.
 * Required by spec's POST /api/customers/post.
 */

public class CustomerCreateRequest {

    @NotNull(message = "storeId is required")
    private Integer storeId;

    @NotBlank(message = "firstName is required")
    @Size(max = 45, message = "firstName must be <= 45 characters")
    private String firstName;

    @NotBlank(message = "lastName is required")
    @Size(max = 45, message = "lastName must be <= 45 characters")
    private String lastName;

    @Email(message = "email must be valid")
    @Size(max = 50, message = "email must be <= 50 characters")
    private String email; // optional

    @NotNull(message = "addressId is required")
    private Integer addressId;

    // Optional - defaults to true if null
    private Boolean active;

	public CustomerCreateRequest(@NotNull(message = "storeId is required") Integer storeId,
			@NotBlank(message = "firstName is required") @Size(max = 45, message = "firstName must be <= 45 characters") String firstName,
			@NotBlank(message = "lastName is required") @Size(max = 45, message = "lastName must be <= 45 characters") String lastName,
			@Email(message = "email must be valid") @Size(max = 50, message = "email must be <= 50 characters") String email,
			@NotNull(message = "addressId is required") Integer addressId, Boolean active) {
		super();
		this.storeId = storeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.addressId = addressId;
		this.active = active;
	}

	public CustomerCreateRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}


}
