package com.filmRental.dto.inventory;

public class StoreInventoryResponse {
    private Integer storeId;
    private String address;
    private String city;
    private Long copies;

    public Integer getStoreId() { return storeId; }
    public void setStoreId(Integer storeId) { this.storeId = storeId; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public Long getCopies() { return copies; }
    public void setCopies(Long copies) { this.copies = copies; }
}