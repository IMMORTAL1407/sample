package com.filmRental.dto.film;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Standard response shape for Film.
 * Includes language and original language names for convenience.
 */
public class FilmResponse {
    private Integer filmId;
    private String title;
    private String description;
    private Integer releaseYear;

    private Integer languageId;
    private String languageName;

    private Integer originalLanguageId;
    private String originalLanguageName;

    private Integer rentalDuration;
    private BigDecimal rentalRate;
    private Integer length;
    private BigDecimal replacementCost;
    private String rating;
    private String specialFeatures;
    private LocalDateTime lastUpdate;

    public FilmResponse(Integer filmId, String title, String description, Integer releaseYear,
                        Integer languageId, String languageName,
                        Integer originalLanguageId, String originalLanguageName,
                        Integer rentalDuration, BigDecimal rentalRate, Integer length,
                        BigDecimal replacementCost, String rating, String specialFeatures,
                        LocalDateTime lastUpdate) {
        this.filmId = filmId;
        this.title = title;
        this.description = description;
        this.releaseYear = releaseYear;
        this.languageId = languageId;
        this.languageName = languageName;
        this.originalLanguageId = originalLanguageId;
        this.originalLanguageName = originalLanguageName;
        this.rentalDuration = rentalDuration;
        this.rentalRate = rentalRate;
        this.length = length;
        this.replacementCost = replacementCost;
        this.rating = rating;
        this.specialFeatures = specialFeatures;
        this.lastUpdate = lastUpdate;
    }

    // Getters only (response DTO)
    public Integer getFilmId() { return filmId; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Integer getReleaseYear() { return releaseYear; }
    public Integer getLanguageId() { return languageId; }
    public String getLanguageName() { return languageName; }
    public Integer getOriginalLanguageId() { return originalLanguageId; }
    public String getOriginalLanguageName() { return originalLanguageName; }
    public Integer getRentalDuration() { return rentalDuration; }
    public BigDecimal getRentalRate() { return rentalRate; }
    public Integer getLength() { return length; }
    public BigDecimal getReplacementCost() { return replacementCost; }
    public String getRating() { return rating; }
    public String getSpecialFeatures() { return specialFeatures; }
    public LocalDateTime getLastUpdate() { return lastUpdate; }

	public FilmResponse() {
		super();
		// TODO Auto-generated constructor stub
	}


	public void setFilmId(Integer filmId) {
		this.filmId = filmId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setReleaseYear(Integer releaseYear) {
		this.releaseYear = releaseYear;
	}

	public void setLanguageId(Integer languageId) {
		this.languageId = languageId;
	}

	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}

	public void setOriginalLanguageId(Integer originalLanguageId) {
		this.originalLanguageId = originalLanguageId;
	}

	public void setOriginalLanguageName(String originalLanguageName) {
		this.originalLanguageName = originalLanguageName;
	}

	public void setRentalDuration(Integer rentalDuration) {
		this.rentalDuration = rentalDuration;
	}

	public void setRentalRate(BigDecimal rentalRate) {
		this.rentalRate = rentalRate;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public void setReplacementCost(BigDecimal replacementCost) {
		this.replacementCost = replacementCost;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}

	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
    
    
}