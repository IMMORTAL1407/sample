package com.filmRental.dto.actor;

public class ActorFilmCountResponse {

    private Integer actorId;
    private String firstName;
    private String lastName;
    private Long filmCount;

    public ActorFilmCountResponse(Integer actorId, String firstName, String lastName, Long filmCount) {
        this.actorId = actorId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.filmCount = filmCount;
    }

	public ActorFilmCountResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getActorId() {
		return actorId;
	}

	public void setActorId(Integer actorId) {
		this.actorId = actorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getFilmCount() {
		return filmCount;
	}

	public void setFilmCount(Long filmCount) {
		this.filmCount = filmCount;
	}

    
    
  
}