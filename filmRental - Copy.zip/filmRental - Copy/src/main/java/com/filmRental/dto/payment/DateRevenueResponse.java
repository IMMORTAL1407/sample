package com.filmRental.dto.payment;

import java.math.BigDecimal;
import java.time.LocalDate;

public class DateRevenueResponse {
    private LocalDate payDate;
    private BigDecimal amount; // cumulative amount till this date

    public LocalDate getPayDate() { return payDate; }
    public void setPayDate(LocalDate payDate) { this.payDate = payDate; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
}