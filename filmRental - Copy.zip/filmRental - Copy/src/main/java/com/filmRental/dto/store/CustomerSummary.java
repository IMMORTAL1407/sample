package com.filmRental.dto.store;

/** Minimal Customer details for store endpoints. */
public class CustomerSummary {
    private Integer customerId;
    private String firstName;
    private String lastName;
    private String email;
    private String phone; // from customer.address.phone

    public Integer getCustomerId() { return customerId; }
    public void setCustomerId(Integer customerId) { this.customerId = customerId; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}