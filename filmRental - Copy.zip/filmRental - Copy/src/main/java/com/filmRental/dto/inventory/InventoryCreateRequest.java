package com.filmRental.dto.inventory;

import jakarta.validation.constraints.NotNull;

public class InventoryCreateRequest {

    @NotNull(message = "filmId is required")
    private Integer filmId;

    @NotNull(message = "storeId is required")
    private Integer storeId;

    public Integer getFilmId() { return filmId; }
    public void setFilmId(Integer filmId) { this.filmId = filmId; }

    public Integer getStoreId() { return storeId; }
    public void setStoreId(Integer storeId) { this.storeId = storeId; }
}