package com.filmRental.dto.payment;

import java.math.BigDecimal;

public class FilmStoreRevenueResponse {
    private Integer storeId;
    private String address;
    private String city;
    private BigDecimal amount;

    public Integer getStoreId() { return storeId; }
    public void setStoreId(Integer storeId) { this.storeId = storeId; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
}
