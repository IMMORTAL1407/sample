package com.filmRental.dto.store;

import jakarta.validation.constraints.NotNull;

public class StoreCreateRequest {

    @NotNull(message = "managerStaffId is required")
    private Integer managerStaffId;

    @NotNull(message = "addressId is required")
    private Integer addressId;

    public Integer getManagerStaffId() { return managerStaffId; }
    public void setManagerStaffId(Integer managerStaffId) { this.managerStaffId = managerStaffId; }

    public Integer getAddressId() { return addressId; }
    public void setAddressId(Integer addressId) { this.addressId = addressId; }
}