package com.filmRental.dto.actor;

import java.time.LocalDateTime;

public class ActorResponse {

    private Integer actorId;
    private String firstName;
    private String lastName;
    private LocalDateTime lastUpdate;

    public ActorResponse(Integer actorId, String firstName, String lastName, LocalDateTime lastUpdate) {
        this.actorId = actorId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.lastUpdate = lastUpdate;
    }

    String getLastName() { return lastName; }
    public LocalDateTime getLastUpdate() { return lastUpdate; }

	public Integer getActorId() {
		return actorId;
	}

	public void setActorId(Integer actorId) {
		this.actorId = actorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public ActorResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    
    
}