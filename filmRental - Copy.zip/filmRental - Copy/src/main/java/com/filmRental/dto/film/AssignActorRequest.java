package com.filmRental.dto.film;

import jakarta.validation.constraints.NotNull;

/** Request body for assigning an Actor to a Film. */
public class AssignActorRequest {
    @NotNull(message = "actorId is required")
    private Integer actorId;

    public Integer getActorId() { return actorId; }
    public void setActorId(Integer actorId) { this.actorId = actorId; }
	public AssignActorRequest(@NotNull(message = "actorId is required") Integer actorId) {
		super();
		this.actorId = actorId;
	}
	public AssignActorRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}