package com.filmRental.dto.film;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

/**
 * Request body for creating a Film.
 * Note: many fields are optional; entity defaults apply if null.
 */
public class FilmCreateRequest {

    @NotBlank(message = "title is required")
    @Size(max = 128, message = "title must be <= 128 chars")
    private String title;

    private String description;                 // TEXT, optional

    @Min(value = 1900, message = "releaseYear must be realistic (>=1900)")
    @Max(value = 2100, message = "releaseYear must be <= 2100")
    private Integer releaseYear;                // SMALLINT, optional

    @NotNull(message = "languageId is required")
    private Integer languageId;                 // FK -> language

    private Integer originalLanguageId;         // optional FK -> language

    private Integer rentalDuration;             // default 3 if null
    private BigDecimal rentalRate;              // default 4.99 if null
    private Integer length;                     // optional
    private BigDecimal replacementCost;         // default 19.99 if null

    @Size(max = 10, message = "rating must be <= 10 chars")
    private String rating;                      // default 'G' if null

    private String specialFeatures;             // TEXT, optional

    // Getters / Setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Integer getReleaseYear() { return releaseYear; }
    public void setReleaseYear(Integer releaseYear) { this.releaseYear = releaseYear; }
    public Integer getLanguageId() { return languageId; }
    public void setLanguageId(Integer languageId) { this.languageId = languageId; }
    public Integer getOriginalLanguageId() { return originalLanguageId; }
    public void setOriginalLanguageId(Integer originalLanguageId) { this.originalLanguageId = originalLanguageId; }
    public Integer getRentalDuration() { return rentalDuration; }
    public void setRentalDuration(Integer rentalDuration) { this.rentalDuration = rentalDuration; }
    public BigDecimal getRentalRate() { return rentalRate; }
    public void setRentalRate(BigDecimal rentalRate) { this.rentalRate = rentalRate; }
    public Integer getLength() { return length; }
    public void setLength(Integer length) { this.length = length; }
    public BigDecimal getReplacementCost() { return replacementCost; }
    public void setReplacementCost(BigDecimal replacementCost) { this.replacementCost = replacementCost; }
    public String getRating() { return rating; }
    public void setRating(String rating) { this.rating = rating; }
    public String getSpecialFeatures() { return specialFeatures; }
    public void setSpecialFeatures(String specialFeatures) { this.specialFeatures = specialFeatures; }
	public FilmCreateRequest(
			@NotBlank(message = "title is required") @Size(max = 128, message = "title must be <= 128 chars") String title,
			String description,
			@Min(value = 1900, message = "releaseYear must be realistic (>=1900)") @Max(value = 2100, message = "releaseYear must be <= 2100") Integer releaseYear,
			@NotNull(message = "languageId is required") Integer languageId, Integer originalLanguageId,
			Integer rentalDuration, BigDecimal rentalRate, Integer length, BigDecimal replacementCost,
			@Size(max = 10, message = "rating must be <= 10 chars") String rating, String specialFeatures) {
		super();
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.languageId = languageId;
		this.originalLanguageId = originalLanguageId;
		this.rentalDuration = rentalDuration;
		this.rentalRate = rentalRate;
		this.length = length;
		this.replacementCost = replacementCost;
		this.rating = rating;
		this.specialFeatures = specialFeatures;
	}
	public FilmCreateRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}