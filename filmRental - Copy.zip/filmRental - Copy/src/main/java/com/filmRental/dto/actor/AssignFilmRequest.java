package com.filmRental.dto.actor;

import jakarta.validation.constraints.NotNull;

public class AssignFilmRequest {

    @NotNull(message = "filmId is required")
    private Integer filmId;

    public Integer getFilmId() { 
    	return filmId; 
    }
    public void setFilmId(Integer filmId) {
    	this.filmId = filmId;
    	}
    
    
	public AssignFilmRequest(@NotNull(message = "filmId is required") Integer filmId) {
		super();
		this.filmId = filmId;
	}
	public AssignFilmRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}