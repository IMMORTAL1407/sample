package com.filmRental.dto.inventory;

public class FilmInventoryResponse {
    private String title;
    private Long copies;

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Long getCopies() { return copies; }
    public void setCopies(Long copies) { this.copies = copies; }
	public FilmInventoryResponse(String title, Long copies) {
		super();
		this.title = title;
		this.copies = copies;
	}
	public FilmInventoryResponse() {
		super();
		// TODO Auto-generated constructor stub
	}


}