package com.filmRental.dto.store;

import jakarta.validation.constraints.NotNull;

/** Request body for PUT /api/store/{id}/manager */
public class AssignManagerRequest {
    @NotNull(message = "managerStaffId is required")
    private Integer managerStaffId;

    public Integer getManagerStaffId() { return managerStaffId; }
    public void setManagerStaffId(Integer managerStaffId) { this.managerStaffId = managerStaffId; }
}