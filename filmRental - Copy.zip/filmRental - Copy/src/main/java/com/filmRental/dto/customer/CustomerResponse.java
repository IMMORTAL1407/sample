package com.filmRental.dto.customer;


import java.time.LocalDateTime;

/**
 * Response shape for Customer endpoints.
 * Includes nested address & store summary for convenience.
 */

public class CustomerResponse {
    // Customer core
    private Integer customerId;
    private String firstName;
    private String lastName;
    private String email;
    private Boolean active;
    private LocalDateTime createDate;
    private LocalDateTime lastUpdate;

    // Store summary
    private Integer storeId;

    // Address summary
    private Integer addressId;
    private String address;
    private String address2;
    private String district;
    private String city;
    private String country;
    private String postalCode;
    private String phone;
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public LocalDateTime getCreateDate() {
		return createDate;
	}
	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}
	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public Integer getStoreId() {
		return storeId;
	}
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
	public Integer getAddressId() {
		return addressId;
	}
	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public CustomerResponse(Integer customerId, String firstName, String lastName, String email, Boolean active,
			LocalDateTime createDate, LocalDateTime lastUpdate, Integer storeId, Integer addressId, String address,
			String address2, String district, String city, String country, String postalCode, String phone) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.active = active;
		this.createDate = createDate;
		this.lastUpdate = lastUpdate;
		this.storeId = storeId;
		this.addressId = addressId;
		this.address = address;
		this.address2 = address2;
		this.district = district;
		this.city = city;
		this.country = country;
		this.postalCode = postalCode;
		this.phone = phone;
	}
	public CustomerResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
    
    
}



