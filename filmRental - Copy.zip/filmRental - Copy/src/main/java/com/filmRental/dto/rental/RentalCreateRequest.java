package com.filmRental.dto.rental;

import jakarta.validation.constraints.NotNull;

public class RentalCreateRequest {

    @NotNull(message = "inventoryId is required")
    private Integer inventoryId;

    @NotNull(message = "customerId is required")
    private Integer customerId;

    @NotNull(message = "staffId is required")
    private Integer staffId;

    public Integer getInventoryId() { return inventoryId; }
    public void setInventoryId(Integer inventoryId) { this.inventoryId = inventoryId; }

    public Integer getCustomerId() { return customerId; }
    public void setCustomerId(Integer customerId) { this.customerId = customerId; }

    public Integer getStaffId() { return staffId; }
    public void setStaffId(Integer staffId) { this.staffId = staffId; }
}