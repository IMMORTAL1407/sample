package com.filmRental.dto.store;

import jakarta.validation.constraints.NotNull;

/** Request body for PUT /api/store/{id}/address */
public class AssignAddressRequest {
    @NotNull(message = "addressId is required")
    private Integer addressId;

    public Integer getAddressId() { return addressId; }
    public void setAddressId(Integer addressId) { this.addressId = addressId; }
}