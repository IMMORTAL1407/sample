package com.filmRental.dto.film;

/** Minimal actor details when listing actors of a film. */
public class ActorSummary {
    private Integer actorId;
    private String firstName;
    private String lastName;

    public ActorSummary(Integer actorId, String firstName, String lastName) {
        this.actorId = actorId;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Integer getActorId() { return actorId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }

	public void setActorId(Integer actorId) {
		this.actorId = actorId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public ActorSummary() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    
    
    
}