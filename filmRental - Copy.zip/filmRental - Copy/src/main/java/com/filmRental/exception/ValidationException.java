package com.filmRental.exception;
//com/example/filmRental/exception/ValidationException.java

public class ValidationException extends RuntimeException {
 public ValidationException(String message) { super(message); }
}