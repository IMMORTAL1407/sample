package com.filmRental.exception;
//com/example/filmRental/exception/NotFoundException.java

public class NotFoundException extends RuntimeException {
 public NotFoundException(String message) { super(message); }
}
