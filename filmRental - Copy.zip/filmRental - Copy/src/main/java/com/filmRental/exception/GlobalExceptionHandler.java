package com.filmRental.exception;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDate;

@ControllerAdvice
public class GlobalExceptionHandler {

 @ExceptionHandler(NotFoundException.class)
 public ResponseEntity<ApiError> handleNotFound(NotFoundException ex, HttpServletRequest req) {
     ApiError body = new ApiError(LocalDate.now(), ex.getMessage(), "uri=" + req.getRequestURI());
     return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
 }

 @ExceptionHandler(ValidationException.class)
 public ResponseEntity<ApiError> handleValidation(ValidationException ex, HttpServletRequest req) {
     ApiError body = new ApiError(LocalDate.now(), "Validation failed: " + ex.getMessage(), "uri=" + req.getRequestURI());
     return ResponseEntity.badRequest().body(body);
 }

 @ExceptionHandler(MethodArgumentNotValidException.class)
 public ResponseEntity<ApiError> handleBeanValidation(MethodArgumentNotValidException ex, HttpServletRequest req) {
     String msg = ex.getBindingResult().getAllErrors().stream()
             .map(err -> err.getDefaultMessage())
             .findFirst().orElse("Validation failed");
     ApiError body = new ApiError(LocalDate.now(), "Validation failed: " + msg, "uri=" + req.getRequestURI());
     return ResponseEntity.badRequest().body(body);
 }

 @ExceptionHandler(Exception.class)
 public ResponseEntity<ApiError> handleOthers(Exception ex, HttpServletRequest req) {
     ApiError body = new ApiError(LocalDate.now(), "Unexpected error", "uri=" + req.getRequestURI());
     return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
 }
}
