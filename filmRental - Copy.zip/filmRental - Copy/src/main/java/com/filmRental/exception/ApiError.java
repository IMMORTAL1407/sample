package com.filmRental.exception;
//com/example/filmRental/exception/ApiError.java

import java.time.LocalDate;
import java.util.Map;

public class ApiError {
 // Matches your required error shape
 private LocalDate timeStamp;
 private String message;
 private String details;

    private int status;
    private String error;
    private String path;
    private Map<String, String> validationErrors;

 public ApiError(LocalDate timeStamp, String message, String details) {
     this.timeStamp = timeStamp;
     this.message = message;
     this.details = details;
 }

 
 public int getStatus() {
	return status;
}


 public void setStatus(int status) {
	this.status = status;
 }


 public String getError() {
	return error;
 }


 public void setError(String error) {
	this.error = error;
 }


 public String getPath() {
	return path;
 }


 public void setPath(String path) {
	this.path = path;
 }


 public Map<String, String> getValidationErrors() {
	return validationErrors;
 }


 public void setValidationErrors(Map<String, String> validationErrors) {
	this.validationErrors = validationErrors;
 }


 public LocalDate getTimeStamp() { return timeStamp; }
 public String getMessage() { return message; }
 public String getDetails() { return details; }
}
