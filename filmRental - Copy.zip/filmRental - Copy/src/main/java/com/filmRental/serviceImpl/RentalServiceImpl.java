package com.filmRental.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.filmRental.dto.rental.*;
import com.filmRental.exception.NotFoundException;
import com.filmRental.model.*;
import com.filmRental.repository.*;
import com.filmRental.service.RentalService;

@Service
@Transactional
public class RentalServiceImpl implements RentalService {

    private final RentalRepository rentalRepo;
    private final InventoryRepository inventoryRepo;
    private final CustomerRepository customerRepo;
    private final StaffRepository staffRepo;

    public RentalServiceImpl(RentalRepository rentalRepo,
                             InventoryRepository inventoryRepo,
                             CustomerRepository customerRepo,
                             StaffRepository staffRepo) {

        this.rentalRepo = rentalRepo;
        this.inventoryRepo = inventoryRepo;
        this.customerRepo = customerRepo;
        this.staffRepo = staffRepo;
    }

    // ------------------- ADD RENTAL ----------------------------
    @Override
    public String addRental(RentalCreateRequest req) {

        Inventory inventory = inventoryRepo.findById(req.getInventoryId())
                .orElseThrow(() -> new NotFoundException("Invalid inventoryId"));

        Customer customer = customerRepo.findById(req.getCustomerId())
                .orElseThrow(() -> new NotFoundException("Invalid customerId"));

        Staff staff = staffRepo.findById(req.getStaffId())
                .orElseThrow(() -> new NotFoundException("Invalid staffId"));

        Rental rental = new Rental();
        rental.setInventory(inventory);
        rental.setCustomer(customer);
        rental.setStaff(staff);
        rental.setRentalDate(LocalDateTime.now());

        rentalRepo.save(rental);

        return "Record Created Successfully";
    }

    // ------------------- MAPPERS ----------------------------
    private TopFilmResponse map(RentalRepository.RentalFilmCount p) {
        TopFilmResponse dto = new TopFilmResponse();
        dto.setFilmId(p.getFilmId());
        dto.setTitle(p.getTitle());
        dto.setRentals(p.getRentals());
        return dto;
    }

    private CustomerSummary map(Customer c) {
        CustomerSummary dto = new CustomerSummary();
        dto.setCustomerId(c.getCustomerId());
        dto.setFirstName(c.getFirstName());
        dto.setLastName(c.getLastName());
        dto.setEmail(c.getEmail());
        dto.setPhone(c.getAddress() != null ? c.getAddress().getPhone() : null);
        return dto;
    }

    private RentalResponse map(Rental r) {
        RentalResponse dto = new RentalResponse();
        dto.setRentalId(r.getRentalId());
        dto.setRentalDate(r.getRentalDate());
        dto.setReturnDate(r.getReturnDate());
        dto.setInventoryId(r.getInventory().getInventoryId());
        dto.setCustomerId(r.getCustomer().getCustomerId());
        dto.setStaffId(r.getStaff().getStaffId());
        return dto;
    }

    // ------------------- QUERIES ----------------------------

    @Override
    public List<?> filmsRentedByCustomer(Integer customerId) {
        return rentalRepo.findFilmsRentedByCustomer(customerId);
    }

    @Override
    public List<TopFilmResponse> topTenFilms() {
        return rentalRepo.topRentedFilms(PageRequest.of(0, 10))
                .stream().map(this::map).toList();
    }

    @Override
    public List<TopFilmResponse> topTenFilmsByStore(Integer storeId) {
        return rentalRepo.topRentedFilmsByStore(storeId, PageRequest.of(0, 10))
                .stream().map(this::map).toList();
    }

    @Override
    public List<CustomerSummary> customersWithDueRentals(Integer storeId) {
        return rentalRepo.findCustomersWithOpenRentalsByStore(storeId)
                .stream().map(this::map).toList();
    }

    @Override
    public RentalResponse updateReturnDate(Integer rentalId) {
        Rental r = rentalRepo.findById(rentalId)
                .orElseThrow(() -> new NotFoundException("Rental not found: " + rentalId));

        r.setReturnDate(LocalDateTime.now());
        return map(r);
    }
}