package com.filmRental.serviceImpl;

import com.filmRental.dto.actor.ActorCreateRequest;
import com.filmRental.dto.actor.ActorFilmCountResponse;
import com.filmRental.dto.actor.ActorFilmResponse;
import com.filmRental.dto.actor.ActorResponse;
import com.filmRental.exception.NotFoundException;
import com.filmRental.exception.ValidationException;
import com.filmRental.model.Actor;
import com.filmRental.model.Film;
import com.filmRental.repository.ActorRepository;
import com.filmRental.repository.FilmRepository;
import com.filmRental.service.ActorService;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

@Service
@Transactional
public class ActorServiceImpl implements ActorService {

    private final ActorRepository actorRepo;
    private final FilmRepository filmRepo;

    public ActorServiceImpl(ActorRepository actorRepo, FilmRepository filmRepo) {
        this.actorRepo = actorRepo;
        this.filmRepo = filmRepo;
    }

    @Override
    public String create(ActorCreateRequest request) {
        if (request.getFirstName().isBlank() || request.getLastName().isBlank()) {
            throw new ValidationException("firstName and lastName must not be blank");
        }

        Actor a = new Actor(request.getFirstName().trim(), request.getLastName().trim());
        actorRepo.save(a);

        return "Record Created Successfully";
    }

    @Override
    @Transactional(readOnly = true)
    public List<ActorResponse> findByFirstName(String fn) {
        return actorRepo.findByFirstNameIgnoreCase(fn).stream()
                .map(this::toDto)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ActorResponse> findByLastName(String ln) {
        return actorRepo.findByLastNameIgnoreCase(ln).stream()
                .map(this::toDto)
                .toList();
    }

    @Override
    public ActorResponse updateFirstName(Integer id, String fn) {
        if (fn == null || fn.isBlank()) throw new ValidationException("firstName must not be blank");

        Actor a = actorRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));

        a.setFirstName(fn.trim());
        return toDto(actorRepo.save(a));
    }

    @Override
    public ActorResponse updateLastName(Integer id, String ln) {
        if (ln == null || ln.isBlank()) throw new ValidationException("lastName must not be blank");

        Actor a = actorRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));

        a.setLastName(ln.trim());
        return toDto(actorRepo.save(a));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ActorFilmResponse> getFilms(Integer actorId) {
        Actor a = actorRepo.findById(actorId)
                .orElseThrow(() -> new NotFoundException("id: " + actorId + " Not Found"));

        return a.getFilms().stream()
                .sorted(Comparator.comparing(Film::getTitle))
                .map(f -> new ActorFilmResponse(f.getFilmId(), f.getTitle(), f.getReleaseYear()))
                .toList();
    }

    @Override
    public List<ActorFilmResponse> assignFilm(Integer actorId, Integer filmId) {
        Actor a = actorRepo.findById(actorId)
                .orElseThrow(() -> new NotFoundException("id: " + actorId + " Not Found"));

        Film f = filmRepo.findById(filmId)
                .orElseThrow(() -> new NotFoundException("filmId: " + filmId + " Not Found"));

        if (!a.getFilms().contains(f))
            a.getFilms().add(f);

        actorRepo.save(a);  // persists relationship

        return a.getFilms().stream()
                .map(x -> new ActorFilmResponse(x.getFilmId(), x.getTitle(), x.getReleaseYear()))
                .toList();
    }
    
    
    @Override
    @Transactional(readOnly = true)
    public List<ActorFilmCountResponse> topTenByFilmCount() {
        var page = PageRequest.of(0, 10);

        return actorRepo.findTopActorsByFilmCount(page).stream()
                .map(p -> new ActorFilmCountResponse(
                        p.getActorId(),
                        p.getFirstName(),
                        p.getLastName(),
                        p.getFilmCount()
                ))
                .toList();
    }

    private ActorResponse toDto(Actor a) {
        return new ActorResponse(
                a.getActorId(),
                a.getFirstName(),
                a.getLastName(),
                a.getLastUpdate()
        );
    }

	
}