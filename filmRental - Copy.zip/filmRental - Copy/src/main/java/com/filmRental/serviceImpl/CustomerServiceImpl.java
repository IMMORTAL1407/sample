package com.filmRental.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.filmRental.dto.customer.CustomerCreateRequest;
import com.filmRental.dto.customer.CustomerResponse;
import com.filmRental.model.Address;
import com.filmRental.model.Customer;
import com.filmRental.model.Store;
import com.filmRental.repository.AddressRepository;
import com.filmRental.repository.CustomerRepository;
import com.filmRental.repository.StoreRepository;
import com.filmRental.service.CustomerService;



@Service

@Transactional
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepo;
    private final AddressRepository addressRepo;
    private final StoreRepository storeRepo;
    
    
    public CustomerServiceImpl (CustomerRepository customerRepo,AddressRepository addressRepo,StoreRepository storeRepo) {
    	this.customerRepo = customerRepo;
    	this.addressRepo=addressRepo;
    	this.storeRepo=storeRepo;
    }

    // ---------------------- CREATE CUSTOMER ----------------------------
    @Override
    public String create(CustomerCreateRequest req) {

        Store store = storeRepo.findById(req.getStoreId())
                .orElseThrow(() -> new RuntimeException("Invalid storeId"));

        Address address = addressRepo.findById(req.getAddressId())
                .orElseThrow(() -> new RuntimeException("Invalid addressId"));

        Customer c = new Customer();
        c.setStore(store);
        c.setFirstName(req.getFirstName());
        c.setLastName(req.getLastName());
        c.setEmail(req.getEmail());
        c.setAddress(address);
        c.setActive(req.getActive() != null ? req.getActive() : true);

        customerRepo.save(c);

        return "Record Created Successfully";
    }

    // ------------------- MAPPING FUNCTION -----------------------
    private CustomerResponse map(Customer c) {
        return new CustomerResponse(
            c.getCustomerId(),
            c.getFirstName(),
            c.getLastName(),
            c.getEmail(),
            c.getActive(),
            c.getCreateDate(),
            c.getLastUpdate(),
            c.getStore().getStoreId(),
            c.getAddress().getAddressId(),
            c.getAddress().getAddress(),
            c.getAddress().getAddress2(),
            c.getAddress().getDistrict(),
            c.getAddress().getCity().getCity(),
            c.getAddress().getCity().getCountry().getCountry(),
            c.getAddress().getPostalCode(),
            c.getAddress().getPhone()
        );
    }

    // ------------------- GET OPERATIONS --------------------------

    @Override
    public List<CustomerResponse> findByLastName(String ln) {
        return customerRepo.findByLastNameIgnoreCase(ln).stream().map(this::map).toList();
    }

    @Override
    public List<CustomerResponse> findByFirstName(String fn) {
        return customerRepo.findByFirstNameIgnoreCase(fn).stream().map(this::map).toList();
    }

    @Override
    public CustomerResponse findByEmail(String email) {
        return customerRepo.findByEmailIgnoreCase(email)
                .map(this::map)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }

    @Override
    public List<CustomerResponse> findByCity(String city) {
        return customerRepo.findByAddress_City_CityIgnoreCase(city).stream().map(this::map).toList();
    }

    @Override
    public List<CustomerResponse> findByCountry(String country) {
        return customerRepo.findByAddress_City_Country_CountryIgnoreCase(country)
                .stream().map(this::map).toList();
    }

    @Override
    public List<CustomerResponse> findActive() {
        return customerRepo.findByActiveTrue().stream().map(this::map).toList();
    }

    @Override
    public List<CustomerResponse> findInactive() {
        return customerRepo.findByActiveFalse().stream().map(this::map).toList();
    }

    @Override
    public List<CustomerResponse> findByPhone(String phone) {
        return customerRepo.findByAddress_Phone(phone).stream().map(this::map).toList();
    }

    // ---------------------- UPDATE OPERATIONS ----------------------------

    @Override
    public CustomerResponse assignAddress(Integer customerId, Integer addressId) {
        Customer c = customerRepo.findById(customerId).orElseThrow();
        Address a = addressRepo.findById(addressId).orElseThrow();
        c.setAddress(a);
        return map(c);
    }

    @Override
    public CustomerResponse updateFirstName(Integer customerId, String firstName) {
        Customer c = customerRepo.findById(customerId).orElseThrow();
        c.setFirstName(firstName);
        return map(c);
    }

    @Override
    public CustomerResponse updateLastName(Integer customerId, String lastName) {
        Customer c = customerRepo.findById(customerId).orElseThrow();
        c.setLastName(lastName);
        return map(c);
    }

    @Override
    public CustomerResponse updateEmail(Integer customerId, String email) {
        Customer c = customerRepo.findById(customerId).orElseThrow();
        c.setEmail(email);
        return map(c);
    }

    @Override
    public CustomerResponse updateStore(Integer customerId, Integer storeId) {
        Customer c = customerRepo.findById(customerId).orElseThrow();
        Store s = storeRepo.findById(storeId).orElseThrow();
        c.setStore(s);
        return map(c);
    }

    @Override
    public CustomerResponse updatePhone(Integer customerId, String phone) {
        Customer c = customerRepo.findById(customerId).orElseThrow();
        c.getAddress().setPhone(phone);
        return map(c);
    }
}