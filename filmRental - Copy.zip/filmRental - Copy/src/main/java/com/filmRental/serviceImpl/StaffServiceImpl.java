package com.filmRental.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.filmRental.dto.staff.StaffCreateRequest;
import com.filmRental.dto.staff.StaffResponse;
import com.filmRental.exception.NotFoundException;
import com.filmRental.model.Address;
import com.filmRental.model.Staff;
import com.filmRental.model.Store;
import com.filmRental.repository.AddressRepository;
import com.filmRental.repository.StaffRepository;
import com.filmRental.repository.StoreRepository;
import com.filmRental.service.StaffService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class StaffServiceImpl implements StaffService {

    private final StaffRepository staffRepo;
    private final AddressRepository addressRepo;
    private final StoreRepository storeRepo;
    
    
    public StaffServiceImpl (StaffRepository staffRepo,AddressRepository addressRepo,StoreRepository storeRepo) {
    	this.staffRepo=staffRepo;
    	this.addressRepo=addressRepo;
    	this.storeRepo =storeRepo;
    }

    // ---------------------- CREATE ----------------------------
    @Override
    public String create(StaffCreateRequest req) {

        Store store = storeRepo.findById(req.getStoreId())
                .orElseThrow(() -> new NotFoundException("Store not found: " + req.getStoreId()));

        Address address = addressRepo.findById(req.getAddressId())
                .orElseThrow(() -> new NotFoundException("Address not found: " + req.getAddressId()));

        Staff s = new Staff();
        s.setStore(store);
        s.setAddress(address);
        s.setFirstName(req.getFirstName());
        s.setLastName(req.getLastName());
        s.setEmail(req.getEmail());
        s.setUsername(req.getUsername());
        s.setPassword(req.getPassword());
        s.setActive(req.getActive() != null ? req.getActive() : Boolean.TRUE);

        staffRepo.save(s);

        return "Record Created Successfully";
    }

    // ------------------- MAPPING -----------------------
    private StaffResponse map(Staff s) {
        StaffResponse dto = new StaffResponse();
        dto.setStaffId(s.getStaffId());
        dto.setFirstName(s.getFirstName());
        dto.setLastName(s.getLastName());
        dto.setEmail(s.getEmail());
        dto.setActive(s.getActive());
        dto.setUsername(s.getUsername());
        dto.setLastUpdate(s.getLastUpdate());
        dto.setHasPicture(s.getPicture() != null && s.getPicture().length > 0);

        if (s.getStore() != null) {
            dto.setStoreId(s.getStore().getStoreId());
        }

        if (s.getAddress() != null) {
            dto.setAddressId(s.getAddress().getAddressId());
            dto.setAddress(s.getAddress().getAddress());
            dto.setAddress2(s.getAddress().getAddress2());
            dto.setDistrict(s.getAddress().getDistrict());
            dto.setPostalCode(s.getAddress().getPostalCode());
            dto.setPhone(s.getAddress().getPhone());

            if (s.getAddress().getCity() != null) {
                dto.setCity(s.getAddress().getCity().getCity());
                if (s.getAddress().getCity().getCountry() != null) {
                    dto.setCountry(s.getAddress().getCity().getCountry().getCountry());
                }
            }
        }

        return dto;
    }

    // ------------------- QUERIES --------------------------
    @Override public List<StaffResponse> findByLastName(String ln) {
        return staffRepo.findByLastNameIgnoreCase(ln).stream().map(this::map).toList();
    }

    @Override public List<StaffResponse> findByFirstName(String fn) {
        return staffRepo.findByFirstNameIgnoreCase(fn).stream().map(this::map).toList();
    }

    @Override public StaffResponse findByEmail(String email) {
        Staff s = staffRepo.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new NotFoundException("Staff not found for email: " + email));
        return map(s);
    }

    @Override public List<StaffResponse> findByCity(String city) {
        return staffRepo.findByAddress_City_CityIgnoreCase(city).stream().map(this::map).toList();
    }

    @Override public List<StaffResponse> findByCountry(String country) {
        return staffRepo.findByAddress_City_Country_CountryIgnoreCase(country).stream().map(this::map).toList();
    }

    @Override public List<StaffResponse> findByPhone(String phone) {
        return staffRepo.findByAddress_Phone(phone).stream().map(this::map).toList();
    }

    // ---------------------- UPDATES ----------------------------
    @Override
    public StaffResponse assignAddress(Integer staffId, Integer addressId) {
        Staff s = staffRepo.findById(staffId).orElseThrow(() -> new NotFoundException("Staff not found: " + staffId));
        Address a = addressRepo.findById(addressId).orElseThrow(() -> new NotFoundException("Address not found: " + addressId));
        s.setAddress(a);
        return map(s);
    }

    @Override
    public StaffResponse updateFirstName(Integer staffId, String firstName) {
        Staff s = staffRepo.findById(staffId).orElseThrow(() -> new NotFoundException("Staff not found: " + staffId));
        s.setFirstName(firstName);
        return map(s);
    }

    @Override
    public StaffResponse updateLastName(Integer staffId, String lastName) {
        Staff s = staffRepo.findById(staffId).orElseThrow(() -> new NotFoundException("Staff not found: " + staffId));
        s.setLastName(lastName);
        return map(s);
    }

    @Override
    public StaffResponse updateEmail(Integer staffId, String email) {
        Staff s = staffRepo.findById(staffId).orElseThrow(() -> new NotFoundException("Staff not found: " + staffId));
        s.setEmail(email);
        return map(s);
    }

    @Override
    public StaffResponse updateStore(Integer staffId, Integer storeId) {
        Staff s = staffRepo.findById(staffId).orElseThrow(() -> new NotFoundException("Staff not found: " + staffId));
        Store st = storeRepo.findById(storeId).orElseThrow(() -> new NotFoundException("Store not found: " + storeId));
        s.setStore(st);
        return map(s);
    }

    @Override
    public StaffResponse updatePhone(Integer staffId, String phone) {
        Staff s = staffRepo.findById(staffId).orElseThrow(() -> new NotFoundException("Staff not found: " + staffId));
        if (s.getAddress() == null) throw new NotFoundException("Staff has no address set");
        s.getAddress().setPhone(phone);
        return map(s);
    }
}
