package com.filmRental.serviceImpl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.filmRental.dto.payment.*;
import com.filmRental.exception.NotFoundException;
import com.filmRental.model.Customer;
import com.filmRental.model.Payment;
import com.filmRental.model.Rental;
import com.filmRental.model.Staff;
import com.filmRental.repository.CustomerRepository;
import com.filmRental.repository.PaymentRepository;
import com.filmRental.repository.RentalRepository;
import com.filmRental.repository.StaffRepository;
import com.filmRental.service.PaymentService;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepo;
    private final CustomerRepository customerRepo;
    private final StaffRepository staffRepo;
    private final RentalRepository rentalRepo;

    public PaymentServiceImpl(PaymentRepository paymentRepo,
                              CustomerRepository customerRepo,
                              StaffRepository staffRepo,
                              RentalRepository rentalRepo) {
        this.paymentRepo = paymentRepo;
        this.customerRepo = customerRepo;
        this.staffRepo = staffRepo;
        this.rentalRepo = rentalRepo;
    }

    // ------------------- CREATE PAYMENT -----------------------
    @Override
    public String create(PaymentCreateRequest req) {

        Customer customer = customerRepo.findById(req.getCustomerId())
                .orElseThrow(() -> new NotFoundException("Customer not found: " + req.getCustomerId()));

        Staff staff = staffRepo.findById(req.getStaffId())
                .orElseThrow(() -> new NotFoundException("Staff not found: " + req.getStaffId()));

        Rental rental = null;
        if (req.getRentalId() != null) {
            rental = rentalRepo.findById(req.getRentalId())
                    .orElseThrow(() -> new NotFoundException("Rental not found: " + req.getRentalId()));
        }

        Payment p = new Payment();
        p.setCustomer(customer);
        p.setStaff(staff);
        p.setRental(rental);
        p.setAmount(req.getAmount());
        p.setPaymentDate(req.getPaymentDate() != null ? req.getPaymentDate() : LocalDateTime.now());

        paymentRepo.save(p);
        return "Record Created Successfully";
    }

    // ------------------- MAPPERS -----------------------
    private FilmRevenueResponse map(PaymentRepository.FilmRevenue pr) {
        FilmRevenueResponse dto = new FilmRevenueResponse();
        dto.setTitle(pr.getTitle());
        dto.setAmount(pr.getAmount());
        return dto;
    }

    private FilmStoreRevenueResponse map(PaymentRepository.FilmStoreRevenue pr) {
        FilmStoreRevenueResponse dto = new FilmStoreRevenueResponse();
        dto.setStoreId(pr.getStoreId());
        dto.setAddress(pr.getAddress());
        dto.setCity(pr.getCity());
        dto.setAmount(pr.getAmount());
        return dto;
    }

    private List<DateRevenueResponse> toCumulative(List<PaymentRepository.DateRevenue> dailyRows) {
        List<DateRevenueResponse> result = new ArrayList<>();
        BigDecimal running = BigDecimal.ZERO;

        for (PaymentRepository.DateRevenue row : dailyRows) {
            LocalDate date = row.getPayDate();
            BigDecimal amount = row.getAmount() != null ? row.getAmount() : BigDecimal.ZERO;
            running = running.add(amount);

            DateRevenueResponse dto = new DateRevenueResponse();
            dto.setPayDate(date);
            dto.setAmount(running);
            result.add(dto);
        }
        return result;
    }

    // ------------------- REVENUE: DATEWISE (CUMULATIVE) -----------------------
    @Override
    public List<DateRevenueResponse> revenueDatewiseAllStores() {
        return toCumulative(paymentRepo.revenueDatewise());
    }

    @Override
    public List<DateRevenueResponse> revenueDatewiseByStore(Integer storeId) {
        return toCumulative(paymentRepo.revenueDatewiseByStore(storeId));
    }

    // ------------------- REVENUE: FILM-WISE -----------------------
    @Override
    public List<FilmRevenueResponse> revenueFilmwiseAllStores() {
        return paymentRepo.revenueFilmwiseAllStores().stream().map(this::map).toList();
    }

    @Override
    public List<FilmStoreRevenueResponse> revenueForFilmStorewise(Integer filmId) {
        return paymentRepo.revenueForFilmStorewise(filmId).stream().map(this::map).toList();
    }

    @Override
    public List<FilmRevenueResponse> revenueFilmsByStore(Integer storeId) {
        return paymentRepo.revenueFilmsByStore(storeId).stream().map(this::map).toList();
    }
}