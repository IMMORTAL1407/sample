package com.filmRental.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.filmRental.dto.store.*;
import com.filmRental.exception.NotFoundException;
import com.filmRental.model.Address;
import com.filmRental.model.Customer;
import com.filmRental.model.Staff;
import com.filmRental.model.Store;
import com.filmRental.repository.AddressRepository;
import com.filmRental.repository.CustomerRepository;
import com.filmRental.repository.StaffRepository;
import com.filmRental.repository.StoreRepository;
import com.filmRental.service.StoreService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class StoreServiceImpl implements StoreService {

    private final StoreRepository storeRepo;
    private final AddressRepository addressRepo;
    private final StaffRepository staffRepo;
    private final CustomerRepository customerRepo;
    
    
    public StoreServiceImpl(StoreRepository storeRepo,
            AddressRepository addressRepo,
            StaffRepository staffRepo,
            CustomerRepository customerRepo) {
this.storeRepo = storeRepo;
this.addressRepo = addressRepo;
this.staffRepo = staffRepo;
this.customerRepo = customerRepo;
}

    // ---------------------- CREATE ----------------------------
    @Override
    public String create(StoreCreateRequest req) {
        Address address = addressRepo.findById(req.getAddressId())
                .orElseThrow(() -> new NotFoundException("Address not found: " + req.getAddressId()));

        Staff manager = staffRepo.findById(req.getManagerStaffId())
                .orElseThrow(() -> new NotFoundException("Manager (staff) not found: " + req.getManagerStaffId()));

        Store st = new Store();
        st.setAddress(address);
        st.setManager(manager);

        // keep store-manager logical consistency
        manager.setStore(st);

        storeRepo.save(st);
        return "Record Created Successfully";
    }

    // ------------------- MAPPING -----------------------
    private StoreResponse map(Store st) {
        StoreResponse dto = new StoreResponse();
        dto.setStoreId(st.getStoreId());
        dto.setLastUpdate(st.getLastUpdate());

        if (st.getManager() != null) {
            dto.setManagerId(st.getManager().getStaffId());
            dto.setManagerFirstName(st.getManager().getFirstName());
            dto.setManagerLastName(st.getManager().getLastName());
            dto.setManagerEmail(st.getManager().getEmail());
        }

        if (st.getAddress() != null) {
            dto.setAddressId(st.getAddress().getAddressId());
            dto.setAddress(st.getAddress().getAddress());
            dto.setAddress2(st.getAddress().getAddress2());
            dto.setDistrict(st.getAddress().getDistrict());
            dto.setPostalCode(st.getAddress().getPostalCode());
            dto.setPhone(st.getAddress().getPhone());
            if (st.getAddress().getCity() != null) {
                dto.setCity(st.getAddress().getCity().getCity());
                if (st.getAddress().getCity().getCountry() != null) {
                    dto.setCountry(st.getAddress().getCity().getCountry().getCountry());
                }
            }
        }
        return dto;
    }

    private StaffSummary mapStaff(Staff s) {
        StaffSummary dto = new StaffSummary();
        dto.setStaffId(s.getStaffId());
        dto.setFirstName(s.getFirstName());
        dto.setLastName(s.getLastName());
        dto.setEmail(s.getEmail());
        dto.setPhone(s.getAddress() != null ? s.getAddress().getPhone() : null);
        return dto;
    }

    private CustomerSummary mapCustomer(Customer c) {
        CustomerSummary dto = new CustomerSummary();
        dto.setCustomerId(c.getCustomerId());
        dto.setFirstName(c.getFirstName());
        dto.setLastName(c.getLastName());
        dto.setEmail(c.getEmail());
        dto.setPhone(c.getAddress() != null ? c.getAddress().getPhone() : null);
        return dto;
    }

    private StoreManagersListResponse map(StoreRepository.StoreManagerSummary p) {
        StoreManagersListResponse dto = new StoreManagersListResponse();
        dto.setStoreId(p.getStoreId());
        dto.setManagerFirstName(p.getManagerFirstName());
        dto.setManagerLastName(p.getManagerLastName());
        dto.setManagerEmail(p.getManagerEmail());
        dto.setStoreAddress(p.getStoreAddress());
        dto.setStoreCity(p.getStoreCity());
        dto.setStorePhone(p.getStorePhone());
        return dto;
    }

    // ------------------- QUERIES --------------------------
    @Override public List<StoreResponse> findByCity(String city) {
        return storeRepo.findByAddress_City_CityIgnoreCase(city).stream().map(this::map).toList();
    }

    @Override public List<StoreResponse> findByCountry(String country) {
        return storeRepo.findByAddress_City_Country_CountryIgnoreCase(country).stream().map(this::map).toList();
    }

    @Override public List<StoreResponse> findByPhone(String phone) {
        return storeRepo.findByAddress_Phone(phone).stream().map(this::map).toList();
    }

    // ---------------------- UPDATES ----------------------------
    @Override
    public StoreResponse assignAddress(Integer storeId, Integer addressId) {
        Store st = storeRepo.findById(storeId)
                .orElseThrow(() -> new NotFoundException("Store not found: " + storeId));
        Address addr = addressRepo.findById(addressId)
                .orElseThrow(() -> new NotFoundException("Address not found: " + addressId));
        st.setAddress(addr);
        return map(st);
    }

    @Override
    public StoreResponse updatePhone(Integer storeId, String phone) {
        Store st = storeRepo.findById(storeId)
                .orElseThrow(() -> new NotFoundException("Store not found: " + storeId));
        if (st.getAddress() == null) throw new NotFoundException("Store has no address set");
        st.getAddress().setPhone(phone);
        return map(st);
    }

    @Override
    public StoreResponse assignManager(Integer storeId, Integer managerStaffId) {
        Store st = storeRepo.findById(storeId)
                .orElseThrow(() -> new NotFoundException("Store not found: " + storeId));
        Staff manager = staffRepo.findById(managerStaffId)
                .orElseThrow(() -> new NotFoundException("Manager (staff) not found: " + managerStaffId));

        st.setManager(manager);
        // keep staff-store consistent
        manager.setStore(st);

        return map(st);
    }

    // ---------------------- RELATIONS ----------------------------
    @Override
    public List<StaffSummary> staffOfStore(Integer storeId) {
        // validate store exists
        storeRepo.findById(storeId).orElseThrow(() -> new NotFoundException("Store not found: " + storeId));
        return staffRepo.findByStore_StoreId(storeId).stream().map(this::mapStaff).toList();
    }

    @Override
    public List<CustomerSummary> customersOfStore(Integer storeId) {
        // validate store exists
        storeRepo.findById(storeId).orElseThrow(() -> new NotFoundException("Store not found: " + storeId));
        return customerRepo.findByStore_StoreId(storeId).stream().map(this::mapCustomer).toList();
    }

    @Override
    public StaffSummary managerOfStore(Integer storeId) {
        Store st = storeRepo.findById(storeId)
                .orElseThrow(() -> new NotFoundException("Store not found: " + storeId));
        if (st.getManager() == null) throw new NotFoundException("Store has no manager assigned");
        return mapStaff(st.getManager());
    }

    @Override
    public List<StoreManagersListResponse> listManagers() {
        return storeRepo.listManagersWithStoreDetails().stream().map(this::map).toList();
    }
}