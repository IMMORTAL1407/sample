package com.filmRental.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.filmRental.dto.inventory.*;
import com.filmRental.exception.NotFoundException;
import com.filmRental.model.Film;
import com.filmRental.model.Inventory;
import com.filmRental.model.Store;
import com.filmRental.repository.FilmRepository;
import com.filmRental.repository.InventoryRepository;
import com.filmRental.repository.StoreRepository;
import com.filmRental.service.InventoryService;

@Service
@Transactional
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepo;
    private final FilmRepository filmRepo;
    private final StoreRepository storeRepo;

    public InventoryServiceImpl(InventoryRepository inventoryRepo,
                                FilmRepository filmRepo,
                                StoreRepository storeRepo) {
        this.inventoryRepo = inventoryRepo;
        this.filmRepo = filmRepo;
        this.storeRepo = storeRepo;
    }

    // ------------------- ADD INVENTORY -----------------------
    @Override
    public String addInventory(InventoryCreateRequest req) {

        Film film = filmRepo.findById(req.getFilmId())
                .orElseThrow(() -> new NotFoundException("Film not found: " + req.getFilmId()));

        Store store = storeRepo.findById(req.getStoreId())
                .orElseThrow(() -> new NotFoundException("Store not found: " + req.getStoreId()));

        Inventory inv = new Inventory(film, store);
        inventoryRepo.save(inv);

        return "Record Created Successfully";
    }

    // ------------------- MAPPERS -----------------------
    private FilmInventoryResponse map(InventoryRepository.FilmInventoryCount p) {
        FilmInventoryResponse dto = new FilmInventoryResponse();
        dto.setTitle(p.getTitle());
        dto.setCopies(p.getCopies());
        return dto;
    }

    private StoreInventoryResponse map(InventoryRepository.StoreInventoryCount p) {
        StoreInventoryResponse dto = new StoreInventoryResponse();
        dto.setStoreId(p.getStoreId());
        dto.setAddress(p.getAddress());
        dto.setCity(p.getCity());
        dto.setCopies(p.getCopies());
        return dto;
    }

    private SingleStoreInventoryResponse map(InventoryRepository.SingleStoreInventoryCount p) {
        SingleStoreInventoryResponse dto = new SingleStoreInventoryResponse();
        dto.setStoreId(p.getStoreId());
        dto.setAddress(p.getAddress());
        dto.setCity(p.getCity());
        dto.setCopies(p.getCopies());
        return dto;
    }

    // ------------------- INVENTORY COUNTS -----------------------
    @Override
    public List<FilmInventoryResponse> getInventoryAcrossAllStores() {
        return inventoryRepo.countCopiesByFilmAcrossStores().stream().map(this::map).toList();
    }

    @Override
    public List<FilmInventoryResponse> getInventoryByStore(Integer storeId) {
        storeRepo.findById(storeId)
                .orElseThrow(() -> new NotFoundException("Store not found: " + storeId));

        return inventoryRepo.countCopiesByFilmInStore(storeId).stream().map(this::map).toList();
    }

    @Override
    public List<StoreInventoryResponse> getInventoryByFilm(Integer filmId) {
        filmRepo.findById(filmId)
                .orElseThrow(() -> new NotFoundException("Film not found: " + filmId));

        return inventoryRepo.countStoresForFilm(filmId).stream().map(this::map).toList();
    }

    @Override
    public SingleStoreInventoryResponse getInventoryOfFilmInStore(Integer filmId, Integer storeId) {
        filmRepo.findById(filmId).orElseThrow(() -> new NotFoundException("Film not found: " + filmId));
        storeRepo.findById(storeId).orElseThrow(() -> new NotFoundException("Store not found: " + storeId));

        return inventoryRepo.countForFilmInStore(filmId, storeId)
                .stream()
                .map(this::map)
                .findFirst()
                .orElse(new SingleStoreInventoryResponse()); // Return empty object if nothing found
    }
}