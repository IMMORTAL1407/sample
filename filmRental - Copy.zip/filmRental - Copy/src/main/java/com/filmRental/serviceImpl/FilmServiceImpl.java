package com.filmRental.serviceImpl;
import com.filmRental.serviceImpl.*;

import com.filmRental.dto.film.ActorSummary;
import com.filmRental.dto.film.FilmCreateRequest;
import com.filmRental.dto.film.FilmResponse;
import com.filmRental.dto.film.YearCountResponse;
import com.filmRental.exception.NotFoundException;
import com.filmRental.exception.ValidationException;
import com.filmRental.model.Actor;
import com.filmRental.model.Category;
import com.filmRental.model.Film;
import com.filmRental.model.FilmCategory;
import com.filmRental.model.Language;
import com.filmRental.repository.ActorRepository;
import com.filmRental.repository.CategoryRepository;
import com.filmRental.repository.FilmCategoryRepository;
import com.filmRental.repository.FilmRepository;
import com.filmRental.repository.LanguageRepository;
import com.filmRental.service.FilmService;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

@Service
@Transactional
public class FilmServiceImpl implements FilmService {

    private final FilmRepository filmRepo;
    private final ActorRepository actorRepo;
    private final LanguageRepository languageRepo;
    private final CategoryRepository categoryRepo;
    private final FilmCategoryRepository filmCategoryRepo;

    public FilmServiceImpl(FilmRepository filmRepo,
                           ActorRepository actorRepo,
                           LanguageRepository languageRepo,
                           CategoryRepository categoryRepo,
                           FilmCategoryRepository filmCategoryRepo) {
        this.filmRepo = filmRepo;
        this.actorRepo = actorRepo;
        this.languageRepo = languageRepo;
        this.categoryRepo = categoryRepo;
        this.filmCategoryRepo = filmCategoryRepo;
    }

    // -------- CREATE --------
    @Override
    public String create(FilmCreateRequest request) {
        if (request.getTitle() == null || request.getTitle().isBlank()) {
            throw new ValidationException("title must not be blank");
        }

        Language lang = languageRepo.findById(request.getLanguageId())
                .orElseThrow(() -> new NotFoundException("languageId: " + request.getLanguageId() + " Not Found"));

        Language origLang = null;
        if (request.getOriginalLanguageId() != null) {
            origLang = languageRepo.findById(request.getOriginalLanguageId())
                    .orElseThrow(() -> new NotFoundException("originalLanguageId: " + request.getOriginalLanguageId() + " Not Found"));
        }

        Film f = new Film(
                request.getTitle().trim(),
                request.getDescription(),
                request.getReleaseYear(),
                lang,
                origLang,
                request.getRentalDuration(),
                request.getRentalRate(),
                request.getLength(),
                request.getReplacementCost(),
                request.getRating(),
                request.getSpecialFeatures()
        );

        filmRepo.save(f);
        return "Record Created Successfully";
    }

    // -------- READ (search) --------
    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByTitle(String title) {
        // Case-insensitive contains search is friendlier than exact match
        return filmRepo.findByTitleContainingIgnoreCase(title).stream()
                .map(this::toFilmResponse)
                .toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByReleaseYear(Integer year) {
        return filmRepo.findByReleaseYear(year).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByRentalDurationGt(Integer rd) {
        return filmRepo.findByRentalDurationGreaterThan(rd).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByRentalDurationLt(Integer rd) {
        return filmRepo.findByRentalDurationLessThan(rd).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByRentalRateGt(BigDecimal rate) {
        return filmRepo.findByRentalRateGreaterThan(rate).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByRentalRateLt(BigDecimal rate) {
        return filmRepo.findByRentalRateLessThan(rate).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByLengthGt(Integer length) {
        return filmRepo.findByLengthGreaterThan(length).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByLengthLt(Integer length) {
        return filmRepo.findByLengthLessThan(length).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findBetweenYears(Integer from, Integer to) {
        return filmRepo.findByReleaseYearBetween(from, to).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByRatingLt(String rating) {
        return filmRepo.findByRatingLessThanBusinessOrder(rating).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByRatingGt(String rating) {
        return filmRepo.findByRatingGreaterThanBusinessOrder(rating).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByLanguage(String lang) {
        if (lang == null || lang.isBlank()) return List.of();
        String trimmed = lang.trim();
        if (isNumeric(trimmed)) {
            return filmRepo.findByLanguage_LanguageId(Integer.parseInt(trimmed)).stream()
                    .map(this::toFilmResponse).toList();
        }
        return filmRepo.findByLanguage_NameIgnoreCase(trimmed).stream().map(this::toFilmResponse).toList();
    }

    @Override @Transactional(readOnly = true)
    public List<YearCountResponse> countByYear() {
        return filmRepo.countFilmsByYear().stream()
                .map(p -> new YearCountResponse(p.getReleaseYear(), p.getCount()))
                .toList();
    }

    @Override @Transactional(readOnly = true)
    public List<ActorSummary> listActors(Integer filmId) {
        // Could also load film and use film.getActors(); using repo query is more direct
        return filmRepo.findActorsByFilmId(filmId).stream()
                .sorted(Comparator.comparing(a -> a.getFirstName() + " " + a.getLastName()))
                .map(a -> new ActorSummary(a.getActorId(), a.getFirstName(), a.getLastName()))
                .toList();
    }

    @Override @Transactional(readOnly = true)
    public List<FilmResponse> findByCategory(String category) {
        if (category == null || category.isBlank()) return List.of();
        String trimmed = category.trim();
        List<Film> films = isNumeric(trimmed)
                ? filmRepo.findFilmsByCategoryId(Integer.parseInt(trimmed))
                : filmRepo.findFilmsByCategoryName(trimmed);
        return films.stream().map(this::toFilmResponse).toList();
    }

    // -------- ASSIGNMENTS / UPDATES --------
    @Override
    public List<ActorSummary> assignActor(Integer filmId, Integer actorId) {
        Film film = filmRepo.findById(filmId)
                .orElseThrow(() -> new NotFoundException("id: " + filmId + " Not Found"));
        Actor actor = actorRepo.findById(actorId)
                .orElseThrow(() -> new NotFoundException("actorId: " + actorId + " Not Found"));

        if (!film.getActors().contains(actor)) {
            film.getActors().add(actor); // Film is owning side
        }
        filmRepo.save(film);

        return film.getActors().stream()
                .map(a -> new ActorSummary(a.getActorId(), a.getFirstName(), a.getLastName()))
                .toList();
    }

    @Override
    public FilmResponse updateTitle(Integer id, String title) {
        if (title == null || title.isBlank()) throw new ValidationException("title must not be blank");
        Film f = filmRepo.findById(id).orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));
        f.setTitle(title.trim());
        return toFilmResponse(filmRepo.save(f));
    }

    @Override
    public FilmResponse updateReleaseYear(Integer id, Integer year) {
        Film f = filmRepo.findById(id).orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));
        f.setReleaseYear(year);
        return toFilmResponse(filmRepo.save(f));
    }

    @Override
    public FilmResponse updateRentalDuration(Integer id, Integer rd) {
        Film f = filmRepo.findById(id).orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));
        f.setRentalDuration(rd);
        return toFilmResponse(filmRepo.save(f));
    }

    @Override
    public FilmResponse updateRentalRate(Integer id, BigDecimal rate) {
        if (rate == null || rate.signum() < 0) throw new ValidationException("rate must be non-negative");
        Film f = filmRepo.findById(id).orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));
        f.setRentalRate(rate);
        return toFilmResponse(filmRepo.save(f));
    }

    @Override
    public FilmResponse updateRating(Integer id, String rating) {
        Film f = filmRepo.findById(id).orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));
        f.setRating(rating);
        return toFilmResponse(filmRepo.save(f));
    }

    @Override
    public FilmResponse updateLanguage(Integer id, Integer languageId) {
        Film f = filmRepo.findById(id).orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));
        Language lang = languageRepo.findById(languageId)
                .orElseThrow(() -> new NotFoundException("languageId: " + languageId + " Not Found"));
        f.setLanguage(lang);
        return toFilmResponse(filmRepo.save(f));
    }

    @Override
    public FilmResponse updateCategory(Integer id, String category) {
        Film f = filmRepo.findById(id).orElseThrow(() -> new NotFoundException("id: " + id + " Not Found"));

        Category cat;
        if (category == null || category.isBlank()) {
            throw new ValidationException("category must not be blank");
        } else if (isNumeric(category.trim())) {
            cat = categoryRepo.findById(Integer.parseInt(category.trim()))
                    .orElseThrow(() -> new NotFoundException("categoryId: " + category + " Not Found"));
        } else {
            cat = categoryRepo.findByNameIgnoreCase(category.trim()).stream().findFirst()
                    .orElseThrow(() -> new NotFoundException("category: " + category + " Not Found"));
        }

        // Ensure mapping exists in film_category
        boolean exists = !filmCategoryRepo.findByFilm_FilmId(f.getFilmId()).stream()
                .filter(fc -> fc.getCategory().getCategoryId().equals(cat.getCategoryId()))
                .toList().isEmpty();

        if (!exists) {
            FilmCategory fc = new FilmCategory(f, cat);
            filmCategoryRepo.save(fc);
        }
        // Return updated film
        return toFilmResponse(f);
    }

    // -------- Helpers --------
    private FilmResponse toFilmResponse(Film f) {
        Integer langId = (f.getLanguage() != null ? f.getLanguage().getLanguageId() : null);
        String langName = (f.getLanguage() != null ? f.getLanguage().getName() : null);
        Integer origLangId = (f.getOriginalLanguage() != null ? f.getOriginalLanguage().getLanguageId() : null);
        String origLangName = (f.getOriginalLanguage() != null ? f.getOriginalLanguage().getName() : null);

        return new FilmResponse(
                f.getFilmId(), f.getTitle(), f.getDescription(), f.getReleaseYear(),
                langId, langName, origLangId, origLangName,
                f.getRentalDuration(), f.getRentalRate(), f.getLength(),
                f.getReplacementCost(), f.getRating(), f.getSpecialFeatures(), f.getLastUpdate()
        );
    }

    private boolean isNumeric(String s) {
        for (int i = 0; i < s.length(); i++) if (!Character.isDigit(s.charAt(i))) return false;
        return !s.isEmpty();
    }
}