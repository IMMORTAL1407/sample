package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Actor;
import com.filmRental.model.Film;

import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

/**
 * Data access for Film.
 * Endpoints covered:
 *  - title/year/betweenYear/duration gt|lt/rate gt|lt/length gt|lt
 *  - rating lt|gt with business order
 *  - language name or id
 *  - countByYear (projection)
 *  - actors by film
 *  - category filters (by id or name)
 */
@Repository
public interface FilmRepository extends JpaRepository<Film, Integer> {

    // Title
    List<Film> findByTitle(String title);
    List<Film> findByTitleContainingIgnoreCase(String title);

    // Release year
    List<Film> findByReleaseYear(Integer year);
    List<Film> findByReleaseYearBetween(Integer from, Integer to);

    // Rental Duration (SMALLINT -> Integer)
    List<Film> findByRentalDurationGreaterThan(Integer rd);
    List<Film> findByRentalDurationLessThan(Integer rd);

    // Rental Rate
    List<Film> findByRentalRateGreaterThan(BigDecimal rate);
    List<Film> findByRentalRateLessThan(BigDecimal rate);

    // Length (SMALLINT -> Integer)
    List<Film> findByLengthGreaterThan(Integer length);
    List<Film> findByLengthLessThan(Integer length);

    // Rating comparisons using business order (G < PG < PG-13 < R < NC-17)
    @Query("""
           SELECT f FROM Film f
           WHERE
           (CASE f.rating
                WHEN 'G' THEN 1
                WHEN 'PG' THEN 2
                WHEN 'PG-13' THEN 3
                WHEN 'R' THEN 4
                WHEN 'NC-17' THEN 5
                ELSE 0 END)
            <
           (CASE
                WHEN :rating = 'G' THEN 1
                WHEN :rating = 'PG' THEN 2
                WHEN :rating = 'PG-13' THEN 3
                WHEN :rating = 'R' THEN 4
                WHEN :rating = 'NC-17' THEN 5
                ELSE 0 END)
           """)
    List<Film> findByRatingLessThanBusinessOrder(@Param("rating") String rating);

    @Query("""
           SELECT f FROM Film f
           WHERE
           (CASE f.rating
                WHEN 'G' THEN 1
                WHEN 'PG' THEN 2
                WHEN 'PG-13' THEN 3
                WHEN 'R' THEN 4
                WHEN 'NC-17' THEN 5
                ELSE 0 END)
            >
           (CASE
                WHEN :rating = 'G' THEN 1
                WHEN :rating = 'PG' THEN 2
                WHEN :rating = 'PG-13' THEN 3
                WHEN :rating = 'R' THEN 4
                WHEN :rating = 'NC-17' THEN 5
                ELSE 0 END)
           """)
    List<Film> findByRatingGreaterThanBusinessOrder(@Param("rating") String rating);

    // Language filters
    List<Film> findByLanguage_LanguageId(Integer languageId);
    List<Film> findByLanguage_NameIgnoreCase(String name);

    // Actors by film
    @Query("""
           SELECT a
           FROM Film f
           JOIN f.actors a
           WHERE f.filmId = :id
           """)
    List<Actor> findActorsByFilmId(@Param("id") Integer filmId);

    // Count films by year (projection)
    interface FilmYearCount {
        Integer getReleaseYear();
        Long getCount();
    }

    @Query("""
           SELECT f.releaseYear AS releaseYear, COUNT(f) AS count
           FROM Film f
           GROUP BY f.releaseYear
           ORDER BY f.releaseYear
           """)
    List<FilmYearCount> countFilmsByYear();

    // Category filters (junction table)
    @Query(value = """
        SELECT f.*
        FROM film f
        JOIN film_category fc ON fc.film_id = f.film_id
        WHERE fc.category_id = :categoryId
        """, nativeQuery = true)
    List<Film> findFilmsByCategoryId(@Param("categoryId") Integer categoryId);

    @Query(value = """
        SELECT f.*
        FROM film f
        JOIN film_category fc ON fc.film_id = f.film_id
        JOIN category c ON c.category_id = fc.category_id
        WHERE LOWER(c.name) = LOWER(:categoryName)
        """, nativeQuery = true)
    List<Film> findFilmsByCategoryName(@Param("categoryName") String categoryName);
}