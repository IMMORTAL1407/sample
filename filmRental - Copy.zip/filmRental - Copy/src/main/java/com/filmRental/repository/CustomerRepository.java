package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Customer;

import java.util.List;
import java.util.Optional;

/**
 * Customer data access.
 * Endpoints covered:
 *  - lastname, firstname, email
 *  - city, country via address
 *  - active / inactive
 *  - phone via address
 *  - store assignment (service handles updates)
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

    List<Customer> findByLastNameIgnoreCase(String lastName);

    List<Customer> findByFirstNameIgnoreCase(String firstName);

    Optional<Customer> findByEmailIgnoreCase(String email);

    List<Customer> findByAddress_City_CityIgnoreCase(String city);

    List<Customer> findByAddress_City_Country_CountryIgnoreCase(String country);

    List<Customer> findByActiveTrue();

    List<Customer> findByActiveFalse();

    List<Customer> findByAddress_Phone(String phone);

    // For Store endpoints (list customers of a store)
    List<Customer> findByStore_StoreId(Integer storeId);
}