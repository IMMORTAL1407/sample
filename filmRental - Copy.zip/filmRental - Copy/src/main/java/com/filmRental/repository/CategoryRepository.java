package com.filmRental.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Category;

import java.util.List;

/**
 * Category master.
 * NOTE: category_id is SMALLINT -> Integer.
 */
@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {
    List<Category> findByNameIgnoreCase(String name);
}
