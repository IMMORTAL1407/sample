package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Address;

import java.util.List;

/**
 * Address repository for city/country/phone-based searches.
 */
@Repository
public interface AddressRepository extends JpaRepository<Address, Integer> {

    List<Address> findByCity_CityIgnoreCase(String city);

    List<Address> findByCity_Country_CountryIgnoreCase(String country);

    List<Address> findByPhone(String phone);
}