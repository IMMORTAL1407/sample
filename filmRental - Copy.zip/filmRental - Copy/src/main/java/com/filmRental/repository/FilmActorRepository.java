package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.filmRental.model.FilmActor;
import com.filmRental.model.FilmActorId;

import java.util.List;

/**
 * Junction between Film and Actor.
 */
@Repository
public interface FilmActorRepository extends JpaRepository<FilmActor, FilmActorId> {

    List<FilmActor> findByFilm_FilmId(Integer filmId);

    List<FilmActor> findByActor_ActorId(Integer actorId);
}