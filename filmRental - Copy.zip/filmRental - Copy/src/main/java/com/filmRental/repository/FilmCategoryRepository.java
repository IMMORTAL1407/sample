package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.filmRental.model.FilmCategory;
import com.filmRental.model.FilmCategoryId;

import java.util.List;

/**
 * Junction between Film and Category.
 */
@Repository
public interface FilmCategoryRepository extends JpaRepository<FilmCategory, FilmCategoryId> {

    List<FilmCategory> findByCategory_CategoryId(Integer categoryId);

    List<FilmCategory> findByFilm_FilmId(Integer filmId);
}
