package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Store;

import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Store data access.
 * Endpoints covered:
 *  - by city, country, phone (via Address)
 *  - manager by store id
 *  - managers list (projection joining manager + store address)
 */
@Repository
public interface StoreRepository extends JpaRepository<Store, Integer> {

    List<Store> findByAddress_City_CityIgnoreCase(String city);

    List<Store> findByAddress_City_Country_CountryIgnoreCase(String country);

    List<Store> findByAddress_Phone(String phone);

    // Manager details by store id -> service reads store.getManager()
    // Managers list projection:
    interface StoreManagerSummary {
        Integer getStoreId();
        String getManagerFirstName();
        String getManagerLastName();
        String getManagerEmail();
        String getStoreAddress();
        String getStoreCity();
        String getStorePhone();
    }

    @Query("""
           SELECT st.storeId            AS storeId,
                  m.firstName           AS managerFirstName,
                  m.lastName            AS managerLastName,
                  m.email               AS managerEmail,
                  addr.address          AS storeAddress,
                  addr.city.city        AS storeCity,
                  addr.phone            AS storePhone
           FROM Store st
           JOIN st.manager m
           JOIN st.address addr
           """)
    List<StoreManagerSummary> listManagersWithStoreDetails();

    // Fetch manager of a specific store as a single projection (optional helper)
    @Query("""
           SELECT st.storeId            AS storeId,
                  m.firstName           AS managerFirstName,
                  m.lastName            AS managerLastName,
                  m.email               AS managerEmail,
                  addr.address          AS storeAddress,
                  addr.city.city        AS storeCity,
                  addr.phone            AS storePhone
           FROM Store st
           JOIN st.manager m
           JOIN st.address addr
           WHERE st.storeId = :storeId
           """)
    List<StoreManagerSummary> managerOfStore(@Param("storeId") Integer storeId);
}