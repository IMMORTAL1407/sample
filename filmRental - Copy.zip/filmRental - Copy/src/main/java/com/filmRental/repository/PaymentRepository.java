package com.filmRental.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Payment;

import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Payment repository for revenue reports.
 * Endpoints covered:
 *  - revenue/datewise (overall)
 *  - revenue/datewise/store/{id}
 *  - revenue/filmwise (all stores)
 *  - revenue/film/{id} (store-wise)
 *  - revenue/films/store/{id} (all films by store)
 *
 * NOTE: We use native queries for date aggregation (DATE(...) and joins).
 */
@Repository
public interface PaymentRepository extends JpaRepository<Payment, Integer> {

    // --- Date-wise revenue (overall) ---
    interface DateRevenue {
        LocalDate getPayDate();
        BigDecimal getAmount();
    }

    @Query(value = """
        SELECT CAST(payment_date AS DATE) AS payDate,
               SUM(amount)               AS amount
        FROM payment
        GROUP BY CAST(payment_date AS DATE)
        ORDER BY payDate
        """, nativeQuery = true)
    List<DateRevenue> revenueDatewise();

    // --- Date-wise revenue by store (via staff.store_id) ---
    @Query(value = """
        SELECT CAST(p.payment_date AS DATE) AS payDate,
               SUM(p.amount)                AS amount
        FROM payment p
        JOIN staff s ON s.staff_id = p.staff_id
        WHERE s.store_id = :storeId
        GROUP BY CAST(p.payment_date AS DATE)
        ORDER BY payDate
        """, nativeQuery = true)
    List<DateRevenue> revenueDatewiseByStore(@Param("storeId") Integer storeId);

    // --- Film-wise revenue across all stores ---
    interface FilmRevenue {
        String getTitle();
        BigDecimal getAmount();
    }

    @Query(value = """
        SELECT f.title   AS title,
               SUM(p.amount) AS amount
        FROM payment p
        JOIN rental r     ON r.rental_id = p.rental_id
        JOIN inventory i  ON i.inventory_id = r.inventory_id
        JOIN film f       ON f.film_id = i.film_id
        GROUP BY f.title
        ORDER BY amount DESC, f.title
        """, nativeQuery = true)
    List<FilmRevenue> revenueFilmwiseAllStores();

    // --- Revenue of a film, store-wise (store address + amount) ---
    interface FilmStoreRevenue {
        Integer getStoreId();
        String getAddress();
        String getCity();
        BigDecimal getAmount();
    }

    @Query(value = """
        SELECT s.store_id            AS storeId,
               a.address             AS address,
               c.city                AS city,
               SUM(p.amount)         AS amount
        FROM payment p
        JOIN rental r     ON r.rental_id = p.rental_id
        JOIN inventory i  ON i.inventory_id = r.inventory_id
        JOIN store s      ON s.store_id = i.store_id
        JOIN address a    ON a.address_id = s.address_id
        JOIN city c       ON c.city_id = a.city_id
        WHERE i.film_id = :filmId
        GROUP BY s.store_id, a.address, c.city
        ORDER BY amount DESC, s.store_id
        """, nativeQuery = true)
    List<FilmStoreRevenue> revenueForFilmStorewise(@Param("filmId") Integer filmId);

    // --- Revenue of all films by store ---
    @Query(value = """
        SELECT f.title     AS title,
               SUM(p.amount) AS amount
        FROM payment p
        JOIN rental r     ON r.rental_id = p.rental_id
        JOIN inventory i  ON i.inventory_id = r.inventory_id
        JOIN film f       ON f.film_id = i.film_id
        WHERE i.store_id = :storeId
        GROUP BY f.title
        ORDER BY amount DESC, f.title
        """, nativeQuery = true)
    List<FilmRevenue> revenueFilmsByStore(@Param("storeId") Integer storeId);
}
