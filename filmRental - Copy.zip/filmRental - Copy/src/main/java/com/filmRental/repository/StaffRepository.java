package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Staff;

import java.util.List;
import java.util.Optional;

/**
 * Staff data access.
 * Endpoints covered:
 *  - lastname, firstname, email
 *  - city, country via address
 *  - phone via address
 *  - list staff of a store
 */
@Repository
public interface StaffRepository extends JpaRepository<Staff, Integer> {
    List<Staff> findByLastNameIgnoreCase(String lastName);

    List<Staff> findByFirstNameIgnoreCase(String firstName);

    Optional<Staff> findByEmailIgnoreCase(String email);

    List<Staff> findByAddress_City_CityIgnoreCase(String city);

    List<Staff> findByAddress_City_Country_CountryIgnoreCase(String country);

    List<Staff> findByAddress_Phone(String phone);

    List<Staff> findByStore_StoreId(Integer storeId);
}