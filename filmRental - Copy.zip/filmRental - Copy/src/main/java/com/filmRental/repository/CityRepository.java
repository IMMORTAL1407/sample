package com.filmRental.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.filmRental.model.City;

import java.util.List;

/**
 * City lookups (used by Address/Customer/Staff/Store filters).
 */
@Repository
public interface CityRepository extends JpaRepository<City, Integer> {

    List<City> findByCityIgnoreCase(String city);

    List<City> findByCountry_CountryIgnoreCase(String country);
}