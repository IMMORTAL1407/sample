package com.filmRental.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Inventory;

import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Inventory repository for counts and listings.
 * Endpoints covered:
 *  - inventory/films (count per film across all stores)
 *  - inventory/store/{id} (count per film in a store)
 *  - inventory/film/{id} (count per store for a film)
 *  - inventory/film/{filmId}/store/{storeId} (single store count for a film)
 */
@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Integer> {

    // Count of copies per film (all stores)
    interface FilmInventoryCount {
        String getTitle();
        Long getCopies();
    }

    @Query("""
           SELECT i.film.title AS title, COUNT(i) AS copies
           FROM Inventory i
           GROUP BY i.film.title
           ORDER BY COUNT(i) DESC, i.film.title
           """)
    List<FilmInventoryCount> countCopiesByFilmAcrossStores();

    // Count of copies per film within one store
    @Query("""
           SELECT i.film.title AS title, COUNT(i) AS copies
           FROM Inventory i
           WHERE i.store.storeId = :storeId
           GROUP BY i.film.title
           ORDER BY COUNT(i) DESC, i.film.title
           """)
    List<FilmInventoryCount> countCopiesByFilmInStore(@Param("storeId") Integer storeId);

    // Count of copies per store for a specific film
    interface StoreInventoryCount {
        Integer getStoreId();
        String getAddress();
        String getCity();
        Long getCopies();
    }

    @Query("""
           SELECT s.storeId            AS storeId,
                  a.address            AS address,
                  a.city.city          AS city,
                  COUNT(i)             AS copies
           FROM Inventory i
           JOIN i.store s
           JOIN s.address a
           WHERE i.film.filmId = :filmId
           GROUP BY s.storeId, a.address, a.city.city
           ORDER BY COUNT(i) DESC, s.storeId
           """)
    List<StoreInventoryCount> countStoresForFilm(@Param("filmId") Integer filmId);

    // Count of copies for a specific film in a specific store
    interface SingleStoreInventoryCount {
        Integer getStoreId();
        String getAddress();
        String getCity();
        Long getCopies();
    }

    @Query("""
           SELECT s.storeId            AS storeId,
                  a.address            AS address,
                  a.city.city          AS city,
                  COUNT(i)             AS copies
           FROM Inventory i
           JOIN i.store s
           JOIN s.address a
           WHERE i.film.filmId = :filmId AND s.storeId = :storeId
           GROUP BY s.storeId, a.address, a.city.city
           """)
    List<SingleStoreInventoryCount> countForFilmInStore(@Param("filmId") Integer filmId,
                                                        @Param("storeId") Integer storeId);

    // Helpers
    List<Inventory> findByStore_StoreId(Integer storeId);
    List<Inventory> findByFilm_FilmId(Integer filmId);
}