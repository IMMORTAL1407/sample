package com.filmRental.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Actor;

import java.util.List;

/**
 * Data access for Actor.
 * Endpoints covered:
 *  - /api/actors/firstname/{fn}, /api/actors/lastname/{ln}
 *  - /api/actors/toptenbyfilmcount (projection)
 */
@Repository
public interface ActorRepository extends JpaRepository<Actor, Integer> {

    List<Actor> findByFirstNameIgnoreCase(String firstName);

    List<Actor> findByLastNameIgnoreCase(String lastName);

    /**
     * Projection for: "Id & Name of Actors with Number of Films"
     */
    interface ActorFilmCount {
        Integer getActorId();
        String getFirstName();
        String getLastName();
        Long getFilmCount();
    }

    /**
     * Top-N actors by film count (use PageRequest.of(0,10) for Top 10).
     */
    @Query("""
           SELECT a.actorId AS actorId,
                  a.firstName AS firstName,
                  a.lastName  AS lastName,
                  COUNT(f)    AS filmCount
           FROM Actor a
           LEFT JOIN a.films f
           GROUP BY a.actorId, a.firstName, a.lastName
           ORDER BY COUNT(f) DESC
           """)
    List<ActorFilmCount> findTopActorsByFilmCount(Pageable pageable);
}