package com.filmRental.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.filmRental.model.Customer;
import com.filmRental.model.Film;
import com.filmRental.model.Rental;

import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Rental repository for renting, queries, and reporting.
 * Endpoints covered:
 *  - rental/customer/{id} -> films rented to a customer
 *  - toptenfilms          -> top 10 most rented films (overall)
 *  - toptenfilms/store/{id} -> per store
 *  - due/store/{id}       -> customers with unreturned rentals in a store
 *  - update return date -> handled in service
 */
@Repository
public interface RentalRepository extends JpaRepository<Rental, Integer> {

    // Films rented to a customer
    @Query("""
           SELECT DISTINCT i.film
           FROM Rental r
           JOIN r.inventory i
           WHERE r.customer.customerId = :customerId
           """)
    List<Film> findFilmsRentedByCustomer(@Param("customerId") Integer customerId);

    // Top-N most rented films (overall)
    interface RentalFilmCount {
        Integer getFilmId();
        String getTitle();
        Long getRentals();
    }

    @Query("""
           SELECT i.film.filmId AS filmId,
                  i.film.title  AS title,
                  COUNT(r)      AS rentals
           FROM Rental r
           JOIN r.inventory i
           GROUP BY i.film.filmId, i.film.title
           ORDER BY COUNT(r) DESC, i.film.title
           """)
    List<RentalFilmCount> topRentedFilms(Pageable pageable);

    // Top-N most rented films for a store
    @Query("""
           SELECT i.film.filmId AS filmId,
                  i.film.title  AS title,
                  COUNT(r)      AS rentals
           FROM Rental r
           JOIN r.inventory i
           WHERE i.store.storeId = :storeId
           GROUP BY i.film.filmId, i.film.title
           ORDER BY COUNT(r) DESC, i.film.title
           """)
    List<RentalFilmCount> topRentedFilmsByStore(@Param("storeId") Integer storeId, Pageable pageable);

    // Customers who have not yet returned the film (by store)
    @Query("""
           SELECT DISTINCT r.customer
           FROM Rental r
           WHERE r.returnDate IS NULL
             AND r.inventory.store.storeId = :storeId
           """)
    List<Customer> findCustomersWithOpenRentalsByStore(@Param("storeId") Integer storeId);
}
