package com.filmRental.service;

import java.util.List;

import com.filmRental.dto.inventory.*;

public interface InventoryService {

    String addInventory(InventoryCreateRequest request);

    List<FilmInventoryResponse> getInventoryAcrossAllStores();
    List<FilmInventoryResponse> getInventoryByStore(Integer storeId);

    List<StoreInventoryResponse> getInventoryByFilm(Integer filmId);

    SingleStoreInventoryResponse getInventoryOfFilmInStore(Integer filmId, Integer storeId);
}