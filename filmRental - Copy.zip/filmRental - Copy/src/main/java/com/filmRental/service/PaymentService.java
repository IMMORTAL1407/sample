package com.filmRental.service;

import java.util.List;

import com.filmRental.dto.payment.*;

public interface PaymentService {

    // PUT (per your spec)
    String create(PaymentCreateRequest request);

    // Revenue - datewise (cumulative)
    List<DateRevenueResponse> revenueDatewiseAllStores();
    List<DateRevenueResponse> revenueDatewiseByStore(Integer storeId);

    // Revenue - filmwise
    List<FilmRevenueResponse> revenueFilmwiseAllStores();
    List<FilmStoreRevenueResponse> revenueForFilmStorewise(Integer filmId);
    List<FilmRevenueResponse> revenueFilmsByStore(Integer storeId);
}