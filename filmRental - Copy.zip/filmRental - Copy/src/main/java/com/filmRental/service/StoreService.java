package com.filmRental.service;

import java.util.List;

import com.filmRental.dto.store.*;

public interface StoreService {

    // POST
    String create(StoreCreateRequest request);

    // GET
    List<StoreResponse> findByCity(String city);
    List<StoreResponse> findByCountry(String country);
    List<StoreResponse> findByPhone(String phone);

    // PUT
    StoreResponse assignAddress(Integer storeId, Integer addressId);
    StoreResponse updatePhone(Integer storeId, String phone);
    StoreResponse assignManager(Integer storeId, Integer managerStaffId);

    // Relations
    List<StaffSummary> staffOfStore(Integer storeId);
    List<CustomerSummary> customersOfStore(Integer storeId);
    StaffSummary managerOfStore(Integer storeId);

    // Projections
    List<StoreManagersListResponse> listManagers();
}