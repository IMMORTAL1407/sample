package com.filmRental.service;


import java.util.List;

import com.filmRental.dto.staff.StaffCreateRequest;
import com.filmRental.dto.staff.StaffResponse;

public interface StaffService {

    // POST
    String create(StaffCreateRequest request);

    // GET
    List<StaffResponse> findByLastName(String ln);
    List<StaffResponse> findByFirstName(String fn);
    StaffResponse findByEmail(String email);
    List<StaffResponse> findByCity(String city);
    List<StaffResponse> findByCountry(String country);
    List<StaffResponse> findByPhone(String phone);

    // PUT
    StaffResponse assignAddress(Integer staffId, Integer addressId);
    StaffResponse updateFirstName(Integer staffId, String firstName);
    StaffResponse updateLastName(Integer staffId, String lastName);
    StaffResponse updateEmail(Integer staffId, String email);
    StaffResponse updateStore(Integer staffId, Integer storeId);
    StaffResponse updatePhone(Integer staffId, String phone);
}