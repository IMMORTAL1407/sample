package com.filmRental.service;

import com.filmRental.dto.actor.*;
import java.util.List;

public interface ActorService {

    String create(ActorCreateRequest request);

    List<ActorResponse> findByFirstName(String fn);
    List<ActorResponse> findByLastName(String ln);

    ActorResponse updateFirstName(Integer id, String fn);
    ActorResponse updateLastName(Integer id, String ln);

    List<ActorFilmResponse> getFilms(Integer actorId);

    List<ActorFilmResponse> assignFilm(Integer actorId, Integer filmId);

    List<ActorFilmCountResponse> topTenByFilmCount();
}
