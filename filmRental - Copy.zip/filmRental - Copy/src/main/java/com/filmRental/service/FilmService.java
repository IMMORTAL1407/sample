package com.filmRental.service;

import java.math.BigDecimal;
import java.util.List;

import com.filmRental.dto.film.*;


public interface FilmService {

    // POST /api/films/post
    String create(FilmCreateRequest request);

    // GET searches
    List<FilmResponse> findByTitle(String title);
    List<FilmResponse> findByReleaseYear(Integer year);
    List<FilmResponse> findByRentalDurationGt(Integer rd);
    List<FilmResponse> findByRentalDurationLt(Integer rd);
    List<FilmResponse> findByRentalRateGt(BigDecimal rate);
    List<FilmResponse> findByRentalRateLt(BigDecimal rate);
    List<FilmResponse> findByLengthGt(Integer length);
    List<FilmResponse> findByLengthLt(Integer length);
    List<FilmResponse> findBetweenYears(Integer from, Integer to);
    List<FilmResponse> findByRatingLt(String rating);
    List<FilmResponse> findByRatingGt(String rating);
    List<FilmResponse> findByLanguage(String lang); // supports id or name
    List<YearCountResponse> countByYear();
    List<ActorSummary> listActors(Integer filmId);
    List<FilmResponse> findByCategory(String category); // supports id or name

    // PUT assignments / updates
    List<ActorSummary> assignActor(Integer filmId, Integer actorId);

    FilmResponse updateTitle(Integer id, String title);
    FilmResponse updateReleaseYear(Integer id, Integer year);
    FilmResponse updateRentalDuration(Integer id, Integer rd);
    FilmResponse updateRentalRate(Integer id, BigDecimal rate);
    FilmResponse updateRating(Integer id, String rating);
    FilmResponse updateLanguage(Integer id, Integer languageId);
    FilmResponse updateCategory(Integer id, String category); // add/ensure mapping
}
