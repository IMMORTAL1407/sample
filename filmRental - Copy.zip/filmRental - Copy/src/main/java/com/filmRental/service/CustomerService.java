package com.filmRental.service;

import com.filmRental.dto.customer.*;
import java.util.List;

/**
 * Business operations for Customer resource.
 * Note: GET and POST routes for customer will be secured via Spring Security (configured later).
 */
public interface CustomerService {

    // POST
    String create(CustomerCreateRequest request);

    // GET queries
    List<CustomerResponse> findByLastName(String ln);
    List<CustomerResponse> findByFirstName(String fn);
    CustomerResponse findByEmail(String email);
    List<CustomerResponse> findByCity(String city);
    List<CustomerResponse> findByCountry(String country);
    List<CustomerResponse> findActive();
    List<CustomerResponse> findInactive();
    List<CustomerResponse> findByPhone(String phone);

    // PUT actions
    CustomerResponse assignAddress(Integer customerId, Integer addressId);
    CustomerResponse updateFirstName(Integer customerId, String firstName);
    CustomerResponse updateLastName(Integer customerId, String lastName);
    CustomerResponse updateEmail(Integer customerId, String email);
    CustomerResponse updateStore(Integer customerId, Integer storeId);
    CustomerResponse updatePhone(Integer customerId, String phone);
}