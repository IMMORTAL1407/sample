package com.filmRental.service;

import java.util.List;

import com.filmRental.dto.rental.*;

public interface RentalService {

    // POST
    String addRental(RentalCreateRequest request);

    // GET
    List<?> filmsRentedByCustomer(Integer customerId);

    List<TopFilmResponse> topTenFilms();

    List<TopFilmResponse> topTenFilmsByStore(Integer storeId);

    List<CustomerSummary> customersWithDueRentals(Integer storeId);

    // UPDATE
    RentalResponse updateReturnDate(Integer rentalId);
}