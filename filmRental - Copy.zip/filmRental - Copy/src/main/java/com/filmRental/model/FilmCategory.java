package com.filmRental.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;


/**
 * Maps to table: film_category (junction between Film and Category)
 * PK: (film_id, category_id)
 */

@Entity
@Table(name = "film_category")
@IdClass(FilmCategoryId.class)
public class FilmCategory {

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "film_id", nullable = false)
    private Film film;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

    

    @PrePersist @PreUpdate
    protected void touch() { this.lastUpdate = LocalDateTime.now(); }



	public Film getFilm() {
		return film;
	}



	public void setFilm(Film film) {
		this.film = film;
	}



	public Category getCategory() {
		return category;
	}



	public void setCategory(Category category) {
		this.category = category;
	}



	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}



	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}



	public FilmCategory(Film film, Category category, LocalDateTime lastUpdate) {
		super();
		this.film = film;
		this.category = category;
		this.lastUpdate = lastUpdate;
	}



	public FilmCategory(Film f, Category cat) {
		// TODO Auto-generated constructor stub
	}
    
    
    

}
