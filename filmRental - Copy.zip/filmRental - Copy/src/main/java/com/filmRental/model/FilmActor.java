package com.filmRental.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
/**
 * Maps to table: film_actor (junction between Film and Actor)
 * PK: (actor_id, film_id)
 */

@Entity
@Table(name = "film_actor")
@IdClass(FilmActorId.class)
public class FilmActor {

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "film_id", nullable = false)
    private Film film;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id", nullable = false)
    private Actor actor;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

   
    @PrePersist @PreUpdate
    protected void touch() { this.lastUpdate = LocalDateTime.now(); }


	public Film getFilm() {
		return film;
	}


	public void setFilm(Film film) {
		this.film = film;
	}


	public Actor getActor() {
		return actor;
	}


	public void setActor(Actor actor) {
		this.actor = actor;
	}


	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}


	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}


	public FilmActor() {
		super();
		// TODO Auto-generated constructor stub
	}


	public FilmActor(Film film, Actor actor, LocalDateTime lastUpdate) {
		super();
		this.film = film;
		this.actor = actor;
		this.lastUpdate = lastUpdate;
	}
    
    

}