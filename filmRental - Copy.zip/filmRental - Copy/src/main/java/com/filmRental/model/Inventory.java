package com.filmRental.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Maps to table: inventory
 * DDL: inventory_id INTEGER, film_id SMALLINT NOT NULL, store_id SMALLINT NOT NULL, last_update TIMESTAMP NOT NULL
 */

@Entity
@Table(name = "inventory", indexes = {
        @Index(name = "idx_fk_film_id", columnList = "film_id"),
        @Index(name = "idx_store_id_film_id", columnList = "store_id, film_id")
})
public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "inventory_id")
    private Integer inventoryId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "film_id", nullable = false)
    private Film film;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "store_id", nullable = false)
    private Store store;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

    public Inventory() {}

    public Inventory(Film film, Store store) {
        this.film = film;
        this.store = store;
    }

    @PrePersist @PreUpdate
    protected void touch() { this.lastUpdate = LocalDateTime.now(); }

    // Getters / Setters
    public Integer getInventoryId() { return inventoryId; }
    public void setInventoryId(Integer inventoryId) { this.inventoryId = inventoryId; }
    public Film getFilm() { return film; }
    public void setFilm(Film film) { this.film = film; }
    public Store getStore() { return store; }
    public void setStore(Store store) { this.store = store; }
    public LocalDateTime getLastUpdate() { return lastUpdate; }
    public void setLastUpdate(LocalDateTime lastUpdate) { this.lastUpdate = lastUpdate; }

	public Inventory(Integer inventoryId, Film film, Store store, LocalDateTime lastUpdate) {
		super();
		this.inventoryId = inventoryId;
		this.film = film;
		this.store = store;
		this.lastUpdate = lastUpdate;
	}
    
}
