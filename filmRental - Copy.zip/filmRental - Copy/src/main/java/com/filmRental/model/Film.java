package com.filmRental.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.filmRental.model.Actor;



/**
 * Maps to table: film
 * DDL highlights:
 *   film_id SMALLINT PK
 *   title VARCHAR(128) NOT NULL
 *   description TEXT NULL
 *   release_year SMALLINT NULL
 *   language_id SMALLINT NOT NULL (FK -> language)
 *   original_language_id SMALLINT NULL (FK -> language)
 *   rental_duration SMALLINT NOT NULL DEFAULT 3
 *   rental_rate DECIMAL(4,2) NOT NULL DEFAULT 4.99
 *   length SMALLINT NULL
 *   replacement_cost DECIMAL(5,2) NOT NULL DEFAULT 19.99
 *   rating VARCHAR(10) DEFAULT 'G' (nullable)
 *   special_features TEXT NULL
 *   last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
 */

@Entity
@Table(name = "film")
public class Film {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // SMALLINT IDENTITY
    @Column(name = "film_id")
    private Integer filmId;

    @Column(name = "title", nullable = false, length = 128)
    private String title;

    // Use columnDefinition to ensure TEXT in Postgres
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "release_year")
    private Integer releaseYear;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "language_id", nullable = false)
    private Language language;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "original_language_id")
    private Language originalLanguage;

    @Column(name = "rental_duration", nullable = false)
    private Integer rentalDuration;

    @Column(name = "rental_rate", nullable = false, precision = 4, scale = 2)
    private BigDecimal rentalRate;

    @Column(name = "length")
    private Integer length;

    @Column(name = "replacement_cost", nullable = false, precision = 5, scale = 2)
    private BigDecimal replacementCost;

    @Column(name = "rating", length = 10)
    private String rating; // nullable in DDL (default 'G')

    @Column(name = "special_features", columnDefinition = "TEXT")
    private String specialFeatures;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

    /**
     * Film owns the many-to-many with Actor via join table "film_actor".
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "film_actor",
        joinColumns        = @JoinColumn(name = "film_id"),
        inverseJoinColumns = @JoinColumn(name = "actor_id")
    )
    private List<Actor> actors = new ArrayList<>();

    

    /** Ensure last_update and sensible defaults on create/update */
    @PrePersist
    protected void prePersist() {
        this.lastUpdate = LocalDateTime.now();
        if (this.rentalDuration == null) this.rentalDuration = 3;          // DDL default
        if (this.rentalRate == null)      this.rentalRate = new BigDecimal("4.99");
        if (this.replacementCost == null) this.replacementCost = new BigDecimal("19.99");
        if (this.rating == null)          this.rating = "G";
    }

    @PreUpdate
    protected void preUpdate() {
        this.lastUpdate = LocalDateTime.now();
    }

	public Film(Integer filmId, String title, String description, Integer releaseYear, Language language,
			Language originalLanguage, Integer rentalDuration, BigDecimal rentalRate, Integer length,
			BigDecimal replacementCost, String rating, String specialFeatures, LocalDateTime lastUpdate,
			List<Actor> actors) {
		super();
		this.filmId = filmId;
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.language = language;
		this.originalLanguage = originalLanguage;
		this.rentalDuration = rentalDuration;
		this.rentalRate = rentalRate;
		this.length = length;
		this.replacementCost = replacementCost;
		this.rating = rating;
		this.specialFeatures = specialFeatures;
		this.lastUpdate = lastUpdate;
		this.actors = actors;
	}

	public Integer getFilmId() {
		return filmId;
	}

	public void setFilmId(Integer filmId) {
		this.filmId = filmId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(Integer releaseYear) {
		this.releaseYear = releaseYear;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	public Language getOriginalLanguage() {
		return originalLanguage;
	}

	public void setOriginalLanguage(Language originalLanguage) {
		this.originalLanguage = originalLanguage;
	}

	public Integer getRentalDuration() {
		return rentalDuration;
	}

	public void setRentalDuration(Integer rentalDuration) {
		this.rentalDuration = rentalDuration;
	}

	public BigDecimal getRentalRate() {
		return rentalRate;
	}

	public void setRentalRate(BigDecimal rentalRate) {
		this.rentalRate = rentalRate;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public BigDecimal getReplacementCost() {
		return replacementCost;
	}

	public void setReplacementCost(BigDecimal replacementCost) {
		this.replacementCost = replacementCost;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getSpecialFeatures() {
		return specialFeatures;
	}

	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}

	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public List<Actor> getActors() {
		return actors;
	}

	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}

	public Film() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Film(String trim, String description2, Integer releaseYear2, Language lang, Language origLang,
			Integer rentalDuration2, BigDecimal rentalRate2, Integer length2, BigDecimal replacementCost2,
			String rating2, String specialFeatures2) {
		// TODO Auto-generated constructor stub
	}
    
    

}