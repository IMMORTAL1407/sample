package com.filmRental.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.*;

/**
 * Maps to table: store
 * DDL: store_id SMALLINT, manager_staff_id SMALLINT UNIQUE NOT NULL, address_id SMALLINT NOT NULL, last_update NOT NULL
 * Relationships:
 *  - manager: One-to-One Staff (unique FK)
 *  - address: Many-to-One Address
 */

@Entity
@Table(name = "store")
public class Store {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "store_id")
    private Integer storeId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manager_staff_id", nullable = false, unique = true)
    private Staff manager;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "address_id", nullable = false)
    private Address address;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

    

    @PrePersist @PreUpdate
    protected void touch() { this.lastUpdate = LocalDateTime.now(); }



	public Integer getStoreId() {
		return storeId;
	}



	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}



	public Staff getManager() {
		return manager;
	}



	public void setManager(Staff manager) {
		this.manager = manager;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}



	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}



	public Store(Integer storeId, Staff manager, Address address, LocalDateTime lastUpdate) {
		super();
		this.storeId = storeId;
		this.manager = manager;
		this.address = address;
		this.lastUpdate = lastUpdate;
	}



	public Store() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	
	
	
    
}
    