package com.filmRental.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Maps to table: actor
 * DDL:
 *   actor_id SMALLINT PK
 *   first_name VARCHAR(45) NOT NULL
 *   last_name  VARCHAR(45) NOT NULL
 *   last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
 */
@Entity
@Table(name = "actor")
public class Actor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // matches SMALLINT IDENTITY
    @Column(name = "actor_id")
    private Integer actorId;

    @Column(name = "first_name", nullable = false, length = 45)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 45)
    private String lastName;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

    /**
     * In the Actor<->Film many-to-many:
     * - Film is the owning side (declares @JoinTable on "film_actor").
     * - Actor is the inverse side (uses mappedBy = "actors").
     */
    @ManyToMany(mappedBy = "actors", fetch = FetchType.LAZY)
    private List<Film> films = new ArrayList<>();

    /** JPA requires a public/protected no-arg constructor */
    public Actor() {}

    /** Convenience constructor (exclude id & lastUpdate; they are generated/managed) */
    public Actor(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName  = lastName;
    }

    /** Keep last_update consistent on create/update */
    @PrePersist
    @PreUpdate
    protected void touch() {
        this.lastUpdate = LocalDateTime.now();
    }
    
    
    

    public Actor(Integer actorId, String firstName, String lastName, LocalDateTime lastUpdate, List<Film> films) {
		super();
		this.actorId = actorId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.lastUpdate = lastUpdate;
		this.films = films;
	}

	// -------- Getters / Setters --------
    public Integer getActorId() { return actorId; }
    public void setActorId(Integer actorId) { this.actorId = actorId; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public LocalDateTime getLastUpdate() { return lastUpdate; }
    public void setLastUpdate(LocalDateTime lastUpdate) { this.lastUpdate = lastUpdate; }

    public List<Film> getFilms() { return films; }
    public void setFilms(List<Film> films) { this.films = films; }
}