package com.filmRental.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Maps to table: staff
 * DDL: staff_id SMALLINT, first_name/last_name VARCHAR(45) NOT NULL,
 *      address_id NOT NULL, picture BYTEA, email VARCHAR(50),
 *      store_id NOT NULL, active BOOLEAN NOT NULL DEFAULT true,
 *      username VARCHAR(16) NOT NULL, password VARCHAR(40), last_update NOT NULL
 */

@Entity
@Table(name = "staff")
public class Staff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "staff_id")
    private Integer staffId;

    @Column(name = "first_name", nullable = false, length = 45)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 45)
    private String lastName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "address_id", nullable = false)
    private Address address;

    @Lob
    @Column(name = "picture")
    private byte[] picture;

    @Column(name = "email", length = 50)
    private String email;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "store_id", nullable = false)
    private Store store;

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "username", nullable = false, length = 16)
    private String username;

    @Column(name = "password", length = 40)
    private String password;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

    

    @PrePersist @PreUpdate
    protected void touch() {
        this.lastUpdate = LocalDateTime.now();
        if (this.active == null) this.active = Boolean.TRUE;
    }



	public Staff(Integer staffId, String firstName, String lastName, Address address, byte[] picture, String email,
			Store store, Boolean active, String username, String password, LocalDateTime lastUpdate) {
		super();
		this.staffId = staffId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.picture = picture;
		this.email = email;
		this.store = store;
		this.active = active;
		this.username = username;
		this.password = password;
		this.lastUpdate = lastUpdate;
	}



	public Staff() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Integer getStaffId() {
		return staffId;
	}



	public void setStaffId(Integer staffId) {
		this.staffId = staffId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	public byte[] getPicture() {
		return picture;
	}



	public void setPicture(byte[] picture) {
		this.picture = picture;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public Store getStore() {
		return store;
	}



	public void setStore(Store store) {
		this.store = store;
	}



	public Boolean getActive() {
		return active;
	}



	public void setActive(Boolean active) {
		this.active = active;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}



	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
    
    

}