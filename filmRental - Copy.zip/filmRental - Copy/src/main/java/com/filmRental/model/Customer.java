package com.filmRental.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Maps to table: customer
 * DDL: customer_id SMALLINT, store_id NOT NULL, first_name/last_name VARCHAR(45) NOT NULL,
 *      email VARCHAR(50), address_id NOT NULL, active BOOLEAN NOT NULL DEFAULT TRUE,
 *      create_date TIMESTAMP NOT NULL, last_update TIMESTAMP DEFAULT now()
 */
@Entity
@Table(name = "customer", indexes = {
        @Index(name = "idx_fk_store_id", columnList = "store_id"),
        @Index(name = "idx_fk_address_id", columnList = "address_id"),
        @Index(name = "idx_last_name", columnList = "last_name")
})
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Integer customerId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "store_id", nullable = false)
    private Store store;

    @Column(name = "first_name", nullable = false, length = 45)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 45)
    private String lastName;

    @Column(name = "email", length = 50)
    private String email;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "address_id", nullable = false)
    private Address address;

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "create_date", nullable = false)
    private LocalDateTime createDate;

    @Column(name = "last_update")
    private LocalDateTime lastUpdate; // nullable in DDL

    public Customer() {}

    public Customer(Store store, String firstName, String lastName, Address address, Boolean active, LocalDateTime createDate) {
        this.store = store;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.active = (active != null ? active : Boolean.TRUE);
        this.createDate = (createDate != null ? createDate : LocalDateTime.now());
    }

    @PrePersist
    protected void prePersist() {
        if (this.active == null) this.active = Boolean.TRUE;
        if (this.createDate == null) this.createDate = LocalDateTime.now();
        this.lastUpdate = LocalDateTime.now(); // DB default also exists
    }

    @PreUpdate
    protected void preUpdate() {
        this.lastUpdate = LocalDateTime.now();
    }

    // Getters / Setters
    public Integer getCustomerId() { return customerId; }
    public void setCustomerId(Integer customerId) { this.customerId = customerId; }
    public Store getStore() { return store; }
    public void setStore(Store store) { this.store = store; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Address getAddress() { return address; }
    public void setAddress(Address address) { this.address = address; }
    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }
    public LocalDateTime getCreateDate() { return createDate; }
    public void setCreateDate(LocalDateTime createDate) { this.createDate = createDate; }
    public LocalDateTime getLastUpdate() { return lastUpdate; }
    public void setLastUpdate(LocalDateTime lastUpdate) { this.lastUpdate = lastUpdate; }

	public Customer(Integer customerId, Store store, String firstName, String lastName, String email, Address address,
			Boolean active, LocalDateTime createDate, LocalDateTime lastUpdate) {
		super();
		this.customerId = customerId;
		this.store = store;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.address = address;
		this.active = active;
		this.createDate = createDate;
		this.lastUpdate = lastUpdate;
	}
    
    
    
}