package com.filmRental.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Maps to table: country
 * DDL: country_id SMALLINT, country VARCHAR(50) NOT NULL, last_update TIMESTAMP NOT NULL DEFAULT now()
 */

@Entity
@Table(name = "country")
public class Country {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "country_id")
    private Integer countryId;

    @Column(name = "country", nullable = false, length = 50)
    private String country;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

   

    @PrePersist @PreUpdate
    protected void touch() {
        this.lastUpdate = LocalDateTime.now();
    }



	public Integer getCountryId() {
		return countryId;
	}



	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}



	public String getCountry() {
		return country;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}



	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}



	public Country() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Country(Integer countryId, String country, LocalDateTime lastUpdate) {
		super();
		this.countryId = countryId;
		this.country = country;
		this.lastUpdate = lastUpdate;
	}
    
    
    
    
    
}