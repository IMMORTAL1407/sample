package com.filmRental.model;

import java.io.Serializable;
import java.util.Objects;


/**
 * Composite key for film_actor (film_id, actor_id).
 */

public class FilmActorId implements Serializable {
    private Integer film;  // property name in FilmActor
    private Integer actor; // property name in FilmActor

    public FilmActorId() {}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FilmActorId that)) return false;
        return Objects.equals(film, that.film) && Objects.equals(actor, that.actor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(film, actor);
    }

	public Integer getFilm() {
		return film;
	}

	public void setFilm(Integer film) {
		this.film = film;
	}

	public Integer getActor() {
		return actor;
	}

	public void setActor(Integer actor) {
		this.actor = actor;
	}

	public FilmActorId(Integer film, Integer actor) {
		super();
		this.film = film;
		this.actor = actor;
	}
    
    
    
}
