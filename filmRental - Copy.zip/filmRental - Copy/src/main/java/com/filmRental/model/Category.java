package com.filmRental.model;
import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Maps to table: category
 * DDL: category_id SMALLINT, name VARCHAR(25) NOT NULL, last_update NOT NULL
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "category")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_id")
    private Integer categoryId; // SMALLINT -> Integer

    @Column(name = "name", nullable = false, length = 25)
    private String name;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;

    
    @PrePersist @PreUpdate
    protected void touch() { this.lastUpdate = LocalDateTime.now(); }


	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Category(Integer categoryId, String name, LocalDateTime lastUpdate) {
		super();
		this.categoryId = categoryId;
		this.name = name;
		this.lastUpdate = lastUpdate;
	}


	public Integer getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}


	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
    
    
    
    
}
