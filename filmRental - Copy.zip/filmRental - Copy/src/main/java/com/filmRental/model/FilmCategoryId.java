package com.filmRental.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Composite key for film_category (film_id, category_id).
 * Must be Serializable and implement equals/hashCode.
 */

public class FilmCategoryId implements Serializable {
    private Integer film;      // matches property name in FilmCategory (field name of @Id relation)
    private Integer category;  // matches property name in FilmCategory

   

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FilmCategoryId that)) return false;
        return Objects.equals(film, that.film) && Objects.equals(category, that.category);
    }

    @Override
    public int hashCode() {
        return Objects.hash(film, category);
    }

	public Integer getFilm() {
		return film;
	}

	public void setFilm(Integer film) {
		this.film = film;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public FilmCategoryId(Integer film, Integer category) {
		super();
		this.film = film;
		this.category = category;
	}

	public FilmCategoryId() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
    
}
