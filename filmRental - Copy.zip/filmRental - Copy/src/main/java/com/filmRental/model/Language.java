package com.filmRental.model;
import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Maps to table: language
 * DDL:
 *   language_id SMALLINT PK
 *   name CHAR(20) NOT NULL
 *   last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
 */

@Entity
@Table(name = "language")
public class Language {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // SMALLINT IDENTITY
    @Column(name = "language_id")
    private Integer languageId;

    // Postgres CHAR(20) is space-padded; mapping as String with length=20 is fine.
    @Column(name = "name", nullable = false, length = 20)
    private String name;

    @Column(name = "last_update", nullable = false)
    private LocalDateTime lastUpdate;


    @PrePersist
    @PreUpdate
    protected void touch() {
        this.lastUpdate = LocalDateTime.now();
    }


	public Integer getLanguageId() {
		return languageId;
	}


	public void setLanguageId(Integer languageId) {
		this.languageId = languageId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}


	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}


	public Language(Integer languageId, String name, LocalDateTime lastUpdate) {
		super();
		this.languageId = languageId;
		this.name = name;
		this.lastUpdate = lastUpdate;
	}


	public Language() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
    
}