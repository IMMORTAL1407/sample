package com.filmRental.controller;

import java.util.List;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.filmRental.dto.payment.*;
import com.filmRental.service.PaymentService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/payment")
@RequiredArgsConstructor
@Validated
public class PaymentController {

    private final PaymentService paymentService;
      
    
    public PaymentController (PaymentService paymentService) {
    	this.paymentService = paymentService;
    }
    // ------------------ PUT (per your spec) -----------------------
    @PutMapping("/add")
    public String addPayment(@Valid @RequestBody PaymentCreateRequest req) {
        return paymentService.create(req);
    }

    // ------------------ REVENUE: DATEWISE (CUMULATIVE) -----------------------
    @GetMapping("/revenue/datewise")
    public List<DateRevenueResponse> revenueDatewiseAllStores() {
        return paymentService.revenueDatewiseAllStores();
    }

    @GetMapping("/revenue/datewise/store/{id}")
    public List<DateRevenueResponse> revenueDatewiseByStore(@PathVariable Integer id) {
        return paymentService.revenueDatewiseByStore(id);
    }

    // ------------------ REVENUE: FILM-WISE -----------------------
    // Spec shows a trailing slash; support both forms.
    @GetMapping({ "/revenue/filmwise/"}) //"/revenue/filmwise"
    public List<FilmRevenueResponse> revenueFilmwiseAllStores() {
        return paymentService.revenueFilmwiseAllStores();
    }

    @GetMapping("/revenue/film/{id}")
    public List<FilmStoreRevenueResponse> revenueForFilmStorewise(@PathVariable Integer id) {
        return paymentService.revenueForFilmStorewise(id);
    }

    @GetMapping("/revenue/films/store/{id}")
    public List<FilmRevenueResponse> revenueFilmsByStore(@PathVariable Integer id) {
        return paymentService.revenueFilmsByStore(id);
    }
}