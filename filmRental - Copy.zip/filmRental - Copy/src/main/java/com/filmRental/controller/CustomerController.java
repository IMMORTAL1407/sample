package com.filmRental.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.filmRental.dto.customer.AssignAddressRequest;
import com.filmRental.dto.customer.CustomerCreateRequest;
import com.filmRental.dto.customer.CustomerResponse;
import com.filmRental.service.CustomerService;



@RestController
@RequestMapping("/api/customers")

public class CustomerController {

    private final CustomerService customerService;
    
    
    public CustomerController (CustomerService customerService) {
    	this.customerService= customerService ;
    }

    // ------------------ POST -----------------------

    @PostMapping("/post")
    public String create(@RequestBody CustomerCreateRequest req) {
        return customerService.create(req);
    }

    // ------------------ GET -----------------------

    @GetMapping("/lastname/{ln}")
    public List<CustomerResponse> byLastName(@PathVariable String ln) {
        return customerService.findByLastName(ln);
    }

    @GetMapping("/firstname/{fn}")
    public List<CustomerResponse> byFirstName(@PathVariable String fn) {
        return customerService.findByFirstName(fn);
    }

    @GetMapping("/email/{email}")
    public CustomerResponse byEmail(@PathVariable String email) {
        return customerService.findByEmail(email);
    }

    @GetMapping("/city/{city}")
    public List<CustomerResponse> byCity(@PathVariable String city) {
        return customerService.findByCity(city);
    }

    @GetMapping("/country/{country}")
    public List<CustomerResponse> byCountry(@PathVariable String country) {
        return customerService.findByCountry(country);
    }

    @GetMapping("/active")
    public List<CustomerResponse> active() {
        return customerService.findActive();
    }

    @GetMapping("/inactive")
    public List<CustomerResponse> inactive() {
        return customerService.findInactive();
    }

    @GetMapping("/phone/{phone}")
    public List<CustomerResponse> byPhone(@PathVariable String phone) {
        return customerService.findByPhone(phone);
    }

    // ------------------ UPDATE / PUT -----------------------

    @PutMapping("/{id}/address")
    public CustomerResponse assignAddress(
            @PathVariable Integer id,
            @RequestBody AssignAddressRequest req) {

        return customerService.assignAddress(id, req.getAddressId());
    }

    @PutMapping("/update/fn/{id}")
    public CustomerResponse updateFirstName(
            @PathVariable Integer id,
            @RequestParam String fn) {

        return customerService.updateFirstName(id, fn);
    }

    @PutMapping("/update/ln/{id}")
    public CustomerResponse updateLastName(
            @PathVariable Integer id,
            @RequestParam String ln) {

        return customerService.updateLastName(id, ln);
    }

    @PutMapping("/update/email/{id}")
    public CustomerResponse updateEmail(
            @PathVariable Integer id,
            @RequestParam String email) {

        return customerService.updateEmail(id, email);
    }

    @PutMapping("/update/store/{id}")
    public CustomerResponse updateStore(
            @PathVariable Integer id,
            @RequestParam Integer storeId) {

        return customerService.updateStore(id, storeId);
    }

    @PutMapping("/update/phone/{id}")
    public CustomerResponse updatePhone(
            @PathVariable Integer id,
            @RequestParam String phone) {

        return customerService.updatePhone(id, phone);
    }
}