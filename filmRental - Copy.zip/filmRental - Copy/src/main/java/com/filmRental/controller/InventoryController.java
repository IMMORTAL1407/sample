package com.filmRental.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.filmRental.dto.inventory.*;
import com.filmRental.service.InventoryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/inventory")

public class InventoryController {

    private final InventoryService inventoryService;
    
    public InventoryController (InventoryService inventoryService) {
    	this.inventoryService = inventoryService;
    }

    @PostMapping("/add")
    public String add(@Valid @RequestBody InventoryCreateRequest req) {
        return inventoryService.addInventory(req);
    }

    @GetMapping("/films")
    public List<FilmInventoryResponse> getAllFilmsInventory() {
        return inventoryService.getInventoryAcrossAllStores();
    }

    @GetMapping("/store/{id}")
    public List<FilmInventoryResponse> getStoreInventory(@PathVariable Integer id) {
        return inventoryService.getInventoryByStore(id);
    }

    @GetMapping("/film/{id}")
    public List<StoreInventoryResponse> getFilmInventory(@PathVariable Integer id) {
        return inventoryService.getInventoryByFilm(id);
    }

    @GetMapping("/film/{filmId}/store/{storeId}")
    public SingleStoreInventoryResponse getFilmInventoryInStore(
            @PathVariable Integer filmId,
            @PathVariable Integer storeId) {

        return inventoryService.getInventoryOfFilmInStore(filmId, storeId);
    }
}