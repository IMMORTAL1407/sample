package com.filmRental.controller;


import com.filmRental.dto.film.*;
import com.filmRental.service.FilmService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * REST endpoints for Film resources.
 * All errors are shaped by GlobalExceptionHandler into:
 * { "timeStamp": "YYYY-MM-DD", "message": "...", "details": "uri=..." }
 */
@RestController
@RequestMapping("/api/films")
public class FilmController {

    private final FilmService filmService;
    public FilmController(FilmService filmService) { this.filmService = filmService; }

    // POST /api/films/post
    @PostMapping("/post")
    public ResponseEntity<String> create(@Valid @RequestBody FilmCreateRequest request) {
        return ResponseEntity.ok(filmService.create(request)); // "Record Created Successfully"
    }

    // --- GET searches ---
    @GetMapping("/title/{title}")
    public List<FilmResponse> byTitle(@PathVariable String title) {
        return filmService.findByTitle(title);
    }

    @GetMapping("/year/{year}")
    public List<FilmResponse> byYear(@PathVariable Integer year) {
        return filmService.findByReleaseYear(year);
    }

    @GetMapping("/duration/gt/{rd}")
    public List<FilmResponse> byDurationGt(@PathVariable Integer rd) {
        return filmService.findByRentalDurationGt(rd);
    }

    @GetMapping("/duration/lt/{rd}")
    public List<FilmResponse> byDurationLt(@PathVariable Integer rd) {
        return filmService.findByRentalDurationLt(rd);
    }

    @GetMapping("/rate/gt/{rate}")
    public List<FilmResponse> byRateGt(@PathVariable BigDecimal rate) {
        return filmService.findByRentalRateGt(rate);
    }

    @GetMapping("/rate/lt/{rate}")
    public List<FilmResponse> byRateLt(@PathVariable BigDecimal rate) {
        return filmService.findByRentalRateLt(rate);
    }

    @GetMapping("/length/gt/{length}")
    public List<FilmResponse> byLengthGt(@PathVariable Integer length) {
        return filmService.findByLengthGt(length);
    }

    @GetMapping("/length/lt/{length}")
    public List<FilmResponse> byLengthLt(@PathVariable Integer length) {
        return filmService.findByLengthLt(length);
    }

    @GetMapping("/betweenyear/{from}/{to}")
    public List<FilmResponse> betweenYears(@PathVariable Integer from, @PathVariable Integer to) {
        return filmService.findBetweenYears(from, to);
    }

    @GetMapping("/rating/lt/{rating}")
    public List<FilmResponse> ratingLt(@PathVariable String rating) {
        return filmService.findByRatingLt(rating);
    }

    @GetMapping("/rating/gt/{rating}")
    public List<FilmResponse> ratingGt(@PathVariable String rating) {
        return filmService.findByRatingGt(rating);
    }

    @GetMapping("/language/{lang}")
    public List<FilmResponse> byLanguage(@PathVariable String lang) {
        return filmService.findByLanguage(lang);
    }

    @GetMapping("/countbyyear")
    public List<YearCountResponse> countByYear() {
        return filmService.countByYear();
    }

    @GetMapping("/{id}/actors")
    public List<ActorSummary> listActors(@PathVariable Integer id) {
        return filmService.listActors(id);
    }

    @GetMapping("/category/{category}")
    public List<FilmResponse> byCategory(@PathVariable String category) {
        return filmService.findByCategory(category);
    }

    // --- PUT assignments / updates ---
    @PutMapping("/{id}/actor")
    public List<ActorSummary> assignActor(@PathVariable Integer id, @Valid @RequestBody AssignActorRequest body) {
        return filmService.assignActor(id, body.getActorId());
    }

    @PutMapping("/update/title/{id}")
    public FilmResponse updateTitle(@PathVariable Integer id, @RequestParam("value") String title) {
        return filmService.updateTitle(id, title);
    }

    @PutMapping("/update/releaseyear/{id}")
    public FilmResponse updateReleaseYear(@PathVariable Integer id, @RequestParam("value") Integer year) {
        return filmService.updateReleaseYear(id, year);
    }

    // NOTE: endpoint name typo preserved to match spec: "rentaldurtion"
    @PutMapping("/update/rentaldurtion/{id}")
    public FilmResponse updateRentalDuration(@PathVariable Integer id, @RequestParam("value") Integer rd) {
        return filmService.updateRentalDuration(id, rd);
    }

    @PutMapping("/update/rentalrate/{id}")
    public FilmResponse updateRentalRate(@PathVariable Integer id, @RequestParam("value") BigDecimal rate) {
        return filmService.updateRentalRate(id, rate);
    }

    @PutMapping("/update/rating/{id}")
    public FilmResponse updateRating(@PathVariable Integer id, @RequestParam("value") String rating) {
        return filmService.updateRating(id, rating);
    }

    @PutMapping("/update/language/{id}")
    public FilmResponse updateLanguage(@PathVariable Integer id, @RequestParam("value") Integer languageId) {
        return filmService.updateLanguage(id, languageId);
    }

    @PutMapping("/update/category/{id}")
    public FilmResponse updateCategory(@PathVariable Integer id, @RequestParam("value") String category) {
        return filmService.updateCategory(id, category);
    }
}
