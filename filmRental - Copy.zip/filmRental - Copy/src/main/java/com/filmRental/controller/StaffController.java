package com.filmRental.controller;

import java.util.List;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.filmRental.dto.staff.AssignAddressRequest;
import com.filmRental.dto.staff.StaffCreateRequest;
import com.filmRental.dto.staff.StaffResponse;
import com.filmRental.service.StaffService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/staff")
@RequiredArgsConstructor
@Validated
public class StaffController {

    private final StaffService staffService;
    
    public StaffController (StaffService staffService ) {
    	this.staffService =staffService;
    	
    }

    // ------------------ POST -----------------------
    @PostMapping("/post")
    public String create(@Valid @RequestBody StaffCreateRequest req) {
        return staffService.create(req);
    }

    // ------------------ GET -----------------------
    @GetMapping("/lastname/{ln}")
    public List<StaffResponse> byLastName(@PathVariable String ln) {
        return staffService.findByLastName(ln);
    }

    @GetMapping("/firstname/{fn}")
    public List<StaffResponse> byFirstName(@PathVariable String fn) {
        return staffService.findByFirstName(fn);
    }

    @GetMapping("/email/{email}")
    public StaffResponse byEmail(@PathVariable String email) {
        return staffService.findByEmail(email);
    }

    @GetMapping("/city/{city}")
    public List<StaffResponse> byCity(@PathVariable String city) {
        return staffService.findByCity(city);
    }

    @GetMapping("/country/{country}")
    public List<StaffResponse> byCountry(@PathVariable String country) {
        return staffService.findByCountry(country);
    }

    @GetMapping("/phone/{phone}")
    public List<StaffResponse> byPhone(@PathVariable String phone) {
        return staffService.findByPhone(phone);
    }

    // ------------------ PUT -----------------------

    // Spec shows uppercase 'Staff' for this one; binding both for safety
    @PutMapping({"/{id}/address", "/../Staff/{id}/address"})
    public StaffResponse assignAddress(
            @PathVariable Integer id,
            @Valid @RequestBody AssignAddressRequest req) {
        return staffService.assignAddress(id, req.getAddressId());
    }

    @PutMapping("/update/fn/{id}")
    public StaffResponse updateFirstName(@PathVariable Integer id, @RequestParam String fn) {
        return staffService.updateFirstName(id, fn);
    }

    @PutMapping("/update/ln/{id}")
    public StaffResponse updateLastName(@PathVariable Integer id, @RequestParam String ln) {
        return staffService.updateLastName(id, ln);
    }

    @PutMapping("/update/email/{id}")
    public StaffResponse updateEmail(@PathVariable Integer id, @RequestParam String email) {
        return staffService.updateEmail(id, email);
    }

    @PutMapping("/update/store/{id}")
    public StaffResponse updateStore(@PathVariable Integer id, @RequestParam Integer storeId) {
        return staffService.updateStore(id, storeId);
    }

    @PutMapping("/update/phone/{id}")
    public StaffResponse updatePhone(@PathVariable Integer id, @RequestParam String phone) {
        return staffService.updatePhone(id, phone);
    }
}