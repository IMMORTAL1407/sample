package com.filmRental.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.filmRental.dto.rental.*;
import com.filmRental.service.RentalService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/rental")
@RequiredArgsConstructor
public class RentalController {

    private final RentalService rentalService;
    public RentalController (RentalService rentalService) {
    	this.rentalService = rentalService;
    }

    @PostMapping("/add")
    public String add(@Valid @RequestBody RentalCreateRequest req) {
        return rentalService.addRental(req);
    }

    @GetMapping("/customer/{id}")
    public List<?> customerRentals(@PathVariable Integer id) {
        return rentalService.filmsRentedByCustomer(id);
    }

    @GetMapping("/toptenfilms")
    public List<TopFilmResponse> topFilms() {
        return rentalService.topTenFilms();
    }

    @GetMapping("/toptenfilms/store/{id}")
    public List<TopFilmResponse> topFilmsByStore(@PathVariable Integer id) {
        return rentalService.topTenFilmsByStore(id);
    }

    @GetMapping("/due/store/{id}")
    public List<CustomerSummary> dueRentals(@PathVariable Integer id) {
        return rentalService.customersWithDueRentals(id);
    }

    @PostMapping("/update/returndate/{id}")
    public RentalResponse updateReturnDate(@PathVariable Integer id) {
        return rentalService.updateReturnDate(id);
    }
}