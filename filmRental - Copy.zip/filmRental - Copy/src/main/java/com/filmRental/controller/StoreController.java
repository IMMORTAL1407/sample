package com.filmRental.controller;

import java.util.List;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.filmRental.dto.store.*;
import com.filmRental.service.StoreService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/store")
@RequiredArgsConstructor
@Validated
public class StoreController {

    private final StoreService storeService;
    
    
    public StoreController (StoreService storeService) {
    	this.storeService =storeService;
    }

    // ------------------ POST -----------------------
    @PostMapping("/post")
    public String create(@Valid @RequestBody StoreCreateRequest req) {
        return storeService.create(req);
    }

    // ------------------ PUT -----------------------
    @PutMapping("/{id}/address")
    public StoreResponse assignAddress(@PathVariable Integer id, @Valid @RequestBody AssignAddressRequest req) {
        return storeService.assignAddress(id, req.getAddressId());
    }

    @PutMapping("/update/phone/{id}")
    public StoreResponse updatePhone(@PathVariable Integer id, @RequestParam String phone) {
        return storeService.updatePhone(id, phone);
    }

    @PutMapping("/{id}/manager")
    public StoreResponse assignManager(@PathVariable Integer id, @Valid @RequestBody AssignManagerRequest req) {
        return storeService.assignManager(id, req.getManagerStaffId());
    }

    // ------------------ GET -----------------------
    @GetMapping("/city/{city}")
    public List<StoreResponse> byCity(@PathVariable String city) {
        return storeService.findByCity(city);
    }

    @GetMapping("/country/{country}")
    public List<StoreResponse> byCountry(@PathVariable String country) {
        return storeService.findByCountry(country);
    }

    @GetMapping("/phone/{phone}")
    public List<StoreResponse> byPhone(@PathVariable String phone) {
        return storeService.findByPhone(phone);
    }

    @GetMapping("/staff/{id}")
    public List<StaffSummary> staffOfStore(@PathVariable Integer id) {
        return storeService.staffOfStore(id);
    }

    @GetMapping("/customer/{id}")
    public List<CustomerSummary> customersOfStore(@PathVariable Integer id) {
        return storeService.customersOfStore(id);
    }

    @GetMapping("/manager/{id}")
    public StaffSummary managerOfStore(@PathVariable Integer id) {
        return storeService.managerOfStore(id);
    }

    @GetMapping("/managers")
    public List<StoreManagersListResponse> listManagers() {
        return storeService.listManagers();
    }
}