package com.filmRental.controller;


import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.filmRental.dto.actor.*;

import com.filmRental.service.ActorService;

import java.util.List;

@RestController
@RequestMapping("/api/actors")
public class ActorController {

    private final ActorService actorService;
    
    
    public ActorController(ActorService actorService) {
        this.actorService = actorService;
    }

    @PostMapping("/post")
    public ResponseEntity<String> create(@Valid @RequestBody ActorCreateRequest request) {
        return ResponseEntity.ok(actorService.create(request));
    }

    @GetMapping("/lastname/{ln}")
    public List<ActorResponse> findByLastName(@PathVariable String ln) {
        return actorService.findByLastName(ln);
    }

    @GetMapping("/firstname/{fn}")
    public List<ActorResponse> findByFirstName(@PathVariable String fn) {
        return actorService.findByFirstName(fn);
    }

    @PutMapping("/update/lastname/{id}")
    public ActorResponse updateLastName(@PathVariable Integer id,
                                        @RequestParam("value") String lastName) {
        return actorService.updateLastName(id, lastName);
    }

    @PutMapping("/update/firstname/{id}")
    public ActorResponse updateFirstName(@PathVariable Integer id,
                                         @RequestParam("value") String firstName) {
        return actorService.updateFirstName(id, firstName);
    }

    @GetMapping("/{id}/films")
    public List<ActorFilmResponse> getFilms(@PathVariable Integer id) {
        return actorService.getFilms(id);
    }

    @PutMapping("/{id}/film")
    public List<ActorFilmResponse> assignFilm(@PathVariable Integer id,
                                              @Valid @RequestBody AssignFilmRequest req) {
        return actorService.assignFilm(id, req.getFilmId());
    }

    @GetMapping("/toptenbyfilmcount")
    public List<ActorFilmCountResponse> topTen() {
        return actorService.topTenByFilmCount();
    }
}
